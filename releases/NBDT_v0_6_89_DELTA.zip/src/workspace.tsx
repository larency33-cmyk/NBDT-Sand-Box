import {Migration,download,useUnsaved} from './enhancements';
import {LessonsLearnedBody} from './lessons-learned-section';
import {GuideExcelImportModal} from './guide-excel-import-modal';
import {applyGuideExcelImport,isFalsePlaceholder,normalizeApplications} from './guide-excel-import.mjs';
import {parseClipboardAssignments} from './tracker-actions.mjs';
import {normalizeLesson,serializeLessons,isLessonPopulated} from './lessons-learned.mjs';
import {setLessonReview,lessonReviewCounts} from './lesson-review.mjs';
import {getAttentionRows} from './overview-attention.mjs';
import {ProjectStartPicker} from './project-start-picker';
import {UNASSIGNED_MEMBER_ID,memberInitial} from './members.mjs';
import {TECH_FIELDS,effectiveStatus,isoWeek,projectToday,csv} from './extended-model.mjs';
import {weekIndexFromIso} from './navigation.mjs';
import {projectWeekDate,projectWeekDays,weekIndexFromDate,currentWeekIndex,todayInTimezone,validDate} from './schedule.mjs';
import {clampWeekViewport,moveWeekViewport} from './week-navigation.mjs';
import {weekHeaderTone} from './week-palette.mjs';
import {setResult} from './model.mjs';
import {guideTechnicalValues,DEVICE_TYPES,registryVisualType,deviceModelValue} from './registry-metadata.mjs';
import {DeviceTypeIcon} from './device-type-icon';
import {guideReviewKey,loadGuideReview,changeGuideCheck,acceptGuideReviewStage} from './guide-review.mjs';
import {validateAggregateMetrics,reportCounts} from './reference-report.mjs';
import {CYBER_STATUSES,normalizeCyberStatus} from './cyber-status.mjs';
import React,{useState,useEffect,useRef} from 'react';
import {createPortal} from 'react-dom';
import {Monitor,AppWindow,Plug,Network,Globe,LockKeyhole,UserRoundKey,Workflow,ShieldCheck,LayoutGrid,Tag,UserRound,MoreVertical,ClipboardCheck,BookOpen,FileText,ExternalLink,ChevronLeft,ChevronRight,ChevronDown,Settings2,Rocket,Layers3,Flag,CalendarDays,Search,Users,AlertCircle,Pencil,Trash2,Plus,Check,X} from 'lucide-react';
import {STAGES,LABELS,uid,weekRange,safeUrl,validateGuide,newGuide,runFor,canAccept,setCheck,acceptStage,counts,assignments} from './model.mjs';
const B=({children,onClick,disabled=false,primary=false,className='',...rest}:any)=><button type="button" className={'nb-button '+(primary?'nb-primary ':'')+className} onClick={onClick} disabled={disabled} {...rest}>{children}</button>;
const Badge=({value}:any)=><span className={'nb-badge nb-status-'+String(value).toLowerCase().replaceAll(' ','-')}>{({'In Progress':'Active','Completed':'Done'} as any)[value]||value}</span>;
function useDirty(dirty:boolean){useEffect(()=>{const f=(e:BeforeUnloadEvent)=>{if(dirty){e.preventDefault();e.returnValue='';}};window.addEventListener('beforeunload',f);return()=>window.removeEventListener('beforeunload',f);},[dirty]);}
/** Technical details live in the same versioned Guide used by Registry cards. */
const beginGuideEdit = (sys:any) => {
 const base=sys.guideDraft||sys.publishedGuide||newGuide();
 const stages=base.stages&&Object.values(base.stages).some((steps:any)=>Array.isArray(steps)&&steps.length) ? base.stages : {...base.stages,...Object.fromEntries(STAGES.map(stage=>[stage,(sys.checkSheetData?.[stage]||[]).map((step:any,i:number)=>typeof step==='string'?{id:'legacy-'+stage+'-'+i,label:step,required:true}:{...step,id:step.id||'legacy-'+stage+'-'+i,label:step.label||step.title||String(step),required:step.required!==false})]))};
 const legacy=Object.fromEntries(TECH_FIELDS.map(k=>[k,sys[k]??'']));
 return {...base,stages,technicalSnapshot:{...legacy,...guideTechnicalValues(sys)}};
};
const guideIdentity = (sys:any) => ({
 name:sys.name||'',description:sys.description||'',assigneeId:sys.assigneeId||'',
 documentationUrl:sys.documentationUrl||'',lessonsLearned:sys.lessonsLearned||'',
});
/** Approved read-only Guide layout; all values come from the same Guide snapshot used by Registry. */
const GuideValue = ({value}: {value:any}) => {
 const text=String(value??'').trim();
 return <>{text && text!=='undefined' && text!=='null' && !isFalsePlaceholder(value) ? text : 'Not specified'}</>;
};
/** The same three approved detail cards; individual fields turn into inputs in place. */
const GuideDetailGroup = ({title,icon:Icon,fields,editing,onEdit,onSave,onCancel,isAdmin,saving}:any) =>
 <section className={'nb40-detail-card'+(editing?' nb41-active-editor':'')} aria-label={title}>
  <div className="nb40-detail-title"><span className="nb40-detail-icon" aria-hidden="true"><Icon size={27} strokeWidth={1.9}/></span><h3>{title}</h3>
   {isAdmin&&!editing&&<button type="button" className="nb41-edit-pencil" aria-label={'Edit '+title} title={'Edit '+title} onClick={onEdit}><Pencil size={16}/></button>}
  </div>
  <dl>{fields.map(([label,value,editor]:any)=><React.Fragment key={label}><dt>{label}</dt><dd>{editing?editor:<GuideValue value={value}/>}</dd></React.Fragment>)}</dl>
  {editing&&<div className="nb41-inline-actions"><B primary disabled={saving} onClick={onSave}><Check size={15}/> Save</B><B disabled={saving} onClick={onCancel}>Cancel</B></div>}
 </section>;
const GuideTechnicalReadout = ({values,deviceVisualType,editingSection,isAdmin,field,identityName,onNameChange,documentationUrl,onDocumentationChange,onEdit,onSave,onCancel,saving}:any) => {
 const os=[values.os,values.osVersion].filter(Boolean).join(' ');
 const model=deviceModelValue({deviceModel:values.deviceModel,deviceType:values.deviceType});
 const common={isAdmin,onSave,onCancel,saving};
 return <div className="nb40-details-grid">
   <GuideDetailGroup {...common} title="Device" icon={({size}:any)=><DeviceTypeIcon type={deviceVisualType} className="nb82-guide-device-icon"/>} editing={editingSection==='device'} onEdit={()=>onEdit('device')} fields={[
    ["Endpoint",model,field('deviceModel','Device model')],
    ["OS",os,<div className="nb41-os-inputs" key="os">{field('os','Operating system',['Windows','Linux','iOS','iPadOS','Android','macOS','Other'])}{field('osVersion','OS version')}</div>],
    ["Naming",values.namingConvention,field('namingConvention','Naming')],
    ["Device type",values.deviceCategory,field('deviceCategory','Device type',DEVICE_TYPES)],
    ["System name",'',<input aria-label="System name" value={identityName} onChange={e=>onNameChange(e.target.value)}/>]
   ].filter((row:any)=>editingSection==='device'||row[0]!=='System name')}/>
   <GuideDetailGroup {...common} title="Network" icon={Network} editing={editingSection==='network'} onEdit={()=>onEdit('network')} fields={[
    ["Connection",values.network,field('network','Connection',['Wired','WiFi','Offline'])],["VLAN",values.vlan,field('vlan','VLAN')],
    ["IP scope",values.ipScope,field('ipScope','IP scope')],["Reservation",values.ipReservation,field('ipReservation','Reservation')]]}/>
   <GuideDetailGroup {...common} title="Access & management" icon={ShieldCheck} editing={editingSection==='access'} onEdit={()=>onEdit('access')} fields={[
    ["Service account",values.serviceAccount,field('serviceAccount','Service account')],["Domain / OU",values.domainOU,field('domainOU','Domain / OU')],
    ["AirWatch tags",values.airWatchTags,field('airWatchTags','AirWatch tags')],["User Account",values.userAccount,field('userAccount','User Account')],
    ["Documentation URL",'',<input aria-label="Documentation URL" type="url" value={documentationUrl} onChange={e=>onDocumentationChange(e.target.value)}/>],
    ["Authentication",'',field('logonType','Authentication')]]
    .filter((row:any)=>editingSection==='access'||!['Documentation URL','Authentication'].includes(row[0]))}/>
  </div>;
};
const GuideApplications = ({value,isAdmin,editing,onEdit,onSave,onCancel,onChange,saving}:any) => {
 const apps=normalizeApplications(value).split('\n').filter(Boolean);
 return <section className={'nb40-applications'+(editing?' nb41-active-editor':'')} aria-label="Applications">
   <div className="nb40-apps-heading"><span className="nb40-apps-icon" aria-hidden="true"><LayoutGrid size={26} strokeWidth={2}/></span><div><h2>Applications</h2><p>{apps.length?'Required software':'No applications specified'}</p></div></div>
   {editing?<div className="nb41-apps-edit"><label htmlFor="nb41-apps-text">Applications · one per line</label><textarea id="nb41-apps-text" aria-label="Required applications" rows={4} value={String(value||'')} onChange={e=>onChange(e.target.value)}/><div className="nb41-inline-actions"><B primary disabled={saving} onClick={onSave}><Check size={15}/> Save</B><B disabled={saving} onClick={onCancel}>Cancel</B></div></div>
   :apps.length>0&&<ul className="nb40-apps-list">{apps.map((name,i)=><li key={i}>{name}</li>)}</ul>}
   {isAdmin&&!editing&&<button type="button" className="nb41-edit-pencil nb41-apps-pencil" aria-label="Edit Applications" title="Edit applications" onClick={onEdit}><Pencil size={16}/></button>}
  </section>;
};
/** Section-scoped, spreadsheet-like editing with a separate Guide-verification checklist. */
export function Guide({sys,project,isAdmin,onClose,onUpdateSystem,initialDeviceId,initialStage,onNavigationChange,initialEdit=false,onDeleteSystem}:any){
 const [stage,setStage]=useState(initialStage||'configuration');
 const [deviceId]=useState(initialDeviceId||'');
 const [technical,setTechnical]=useState(true);
 const [message,setMessage]=useState('');
 const [editingSection,setEditingSection]=useState<string|null>(initialEdit?'device':null);
 const [draft,setDraft]=useState<any>(()=>beginGuideEdit(sys));
 const [identity,setIdentity]=useState<any>(()=>guideIdentity(sys));
 const legacyLessons=()=>Array.isArray(sys.lessonsLearnedItems)?sys.lessonsLearnedItems:(sys.lessonsLearned?[{id:'legacy-lesson-'+sys.id,text:String(sys.lessonsLearned),checked:false}]:[]);
 const [lessonDraft,setLessonDraft]=useState<any[]>(legacyLessons);
 const [saving,setSaving]=useState(false);
 const [showExcelImport,setShowExcelImport]=useState(false);
 const pending=useRef(false);
 const device=(sys.devices||[]).find((d:any)=>d.id===deviceId);
 const run=runFor(sys,device);
 const guide=editingSection==='checklist'?draft:(run?.snapshot||beginGuideEdit(sys));
 const guideKey=guideReviewKey(guide);
 const savedReview=loadGuideReview(sys.guideReview,guide);
 const [reviewDraft,setReviewDraft]=useState<any>(()=>savedReview);
 const reviewDirty=!run&&JSON.stringify(reviewDraft)!==JSON.stringify(savedReview);
 const sectionDirty=editingSection!==null&&(JSON.stringify(draft)!==JSON.stringify(beginGuideEdit(sys))||JSON.stringify(identity)!==JSON.stringify(guideIdentity(sys))||(editingSection==='lessons'&&JSON.stringify(lessonDraft)!==JSON.stringify(legacyLessons().map(normalizeLesson))));
 const dirty=sectionDirty||reviewDirty;
 useDirty(dirty);useUnsaved(dirty);
 useEffect(()=>{if(!reviewDirty)setReviewDraft(loadGuideReview(sys.guideReview,guide));},[sys.guideReview,guideKey]);
 const close=()=>{if(!dirty||confirm('Discard unsaved guide changes and checklist progress?'))onClose();};
 useEffect(()=>{const handler=(e:KeyboardEvent)=>{if(e.key==='Escape')close();};window.addEventListener('keydown',handler);return()=>window.removeEventListener('keydown',handler);},[dirty,onClose]);
 const url=safeUrl(sys.documentationUrl);
 const technicalValues=editingSection&&editingSection!=='lessons'?draft.technicalSnapshot:guideTechnicalValues(sys);
 const items=guide?.stages?.[stage]||[];
 const previewItems=items.length?items:(sys.checkSheetData?.[stage]||[]);
 const reviewRun=run||{...reviewDraft,snapshot:guide};
 const marked=previewItems.filter((item:any)=>reviewRun.checks?.[item.id]).length;
 const update=async(next:any)=>{if(pending.current)return false;pending.current=true;setSaving(true);try{await onUpdateSystem(next);setMessage('Changes saved');return true;}catch(error:any){setMessage('Save failed: '+error.message);return false;}finally{pending.current=false;setSaving(false);}};
 const updateRun=(next:any)=>update({...sys,deviceRuns:[...(sys.deviceRuns||[]).filter((r:any)=>r.id!==next.id),next]});
 const setTech=(key:string,value:string)=>{
  if(key==='deviceModel')setDraft((prev:any)=>({...prev,technicalSnapshot:{...prev.technicalSnapshot,[key]:value,deviceType:value}}));
  else setDraft((prev:any)=>({...prev,technicalSnapshot:{...prev.technicalSnapshot,[key]:value}}));
 };
 const setMeta=(key:string,value:string)=>setIdentity((prev:any)=>({...prev,[key]:value}));
 const inlineField=(key:string,label:string,options?:readonly string[])=>options?
  <select aria-label={label} value={String(technicalValues[key]??'')} onChange={e=>setTech(key,e.target.value)}><option value="">Not specified</option>{options.map(v=><option key={v} value={v}>{v}</option>)}</select>:
  <input aria-label={label} value={isFalsePlaceholder(technicalValues[key])?'':String(technicalValues[key]??'')} onChange={e=>setTech(key,e.target.value)}/>;
 const beginEdit=(section:string)=>{if(!isAdmin||editingSection)return;if(reviewDirty&&!confirm('Discard unsaved checklist progress?'))return;
  const nextDraft=beginGuideEdit(sys);
  if(section==='applications')nextDraft.technicalSnapshot={...nextDraft.technicalSnapshot,appList:normalizeApplications(nextDraft.technicalSnapshot?.appList)};
  setReviewDraft(savedReview);setDraft(nextDraft);setIdentity(guideIdentity(sys));setLessonDraft(legacyLessons().map(normalizeLesson));setMessage('');setEditingSection(section);if(section==='device'||section==='network'||section==='access')setTechnical(true);
 };
 const cancelEdit=()=>{if(sectionDirty&&!confirm('Discard unsaved section changes?'))return;setDraft(beginGuideEdit(sys));setIdentity(guideIdentity(sys));setLessonDraft(legacyLessons());setEditingSection(null);setMessage('');};
 const validateDetails=()=>{
  if(!identity.name.trim()){setMessage('System name is required.');return false;}
  if(identity.documentationUrl&&!safeUrl(identity.documentationUrl)){setMessage('Documentation URL must be a valid HTTPS link.');return false;}
  if(draft.technicalSnapshot.os!==guideTechnicalValues(sys).os&&(sys.deviceRuns||[]).some((r:any)=>!r.archived)){setMessage('Platform changes require a new endpoint profile when device runs exist.');return false;}
  return true;
 };
 const updatedSystem=(guideChanges:any)=>{
  const technicalSnapshot={...guideChanges.technicalSnapshot,appList:normalizeApplications(guideChanges.technicalSnapshot?.appList)};
  return {...sys,...technicalSnapshot,...identity,name:identity.name.trim(),description:identity.description,guideDraft:{...guideChanges,technicalSnapshot}};
 };
 const saveSection=async()=>{if(!validateDetails())return;
  if(editingSection==='checklist'){
   const errors=validateGuide({...sys,os:draft.technicalSnapshot.os},draft);
   if(errors.length){setMessage(errors.join('; '));return;}
  }
  if(editingSection==='lessons'&&lessonDraft.some((item:any)=>isLessonPopulated(item)&&!String(item.lessonLearned||'').trim())){setMessage('Each lesson must have a title.');return;}
  const next=editingSection==='lessons'?{...sys,...serializeLessons(lessonDraft)}:updatedSystem(draft);
  if(await update(next))setEditingSection(null);
 };
 const publish=async()=>{
  if(!validateDetails())return;
  const errors=validateGuide({...sys,os:draft.technicalSnapshot.os},draft);
  if(errors.length){setMessage(errors.join('; '));return;}
  if(!confirm('Publish a reviewed guide version? Existing device runs keep their snapshots. Saved guide checklist verification will reset when steps change.'))return;
  const next={...draft,platform:draft.technicalSnapshot.os,version:(sys.publishedGuide?.version||0)+1,publishedAt:new Date().toISOString(),publishedBy:'local-demo',technicalSnapshot:{...draft.technicalSnapshot},valueStates:sys.valueStates||{}};
  if(await update({...updatedSystem(next),publishedGuide:next,guideDraft:null})){setDraft(next);setEditingSection(null);}
 };
 const persistReview=async(next=reviewDraft)=>{const normalized=loadGuideReview(next,guide);if(await update({...sys,guideReview:normalized})){setReviewDraft(normalized);return true;}return false;};
 const markCheck=async(item:any,value:boolean)=>{
  try{
   if(reviewRun.accepted?.[stage]&&!confirm('This stage was accepted. Reopen this and later stages?'))return;
   if(run){await updateRun(setCheck(run,stage,item.id,value));}
   else{setReviewDraft(changeGuideCheck(reviewDraft,guide,stage,item.id,value));setMessage('Unsaved checklist changes');}
  }catch(error:any){setMessage(error.message);}
 };
 const acceptCurrentStage=async()=>{try{
  if(run){const didSave=await updateRun(acceptStage(run,stage));if(!didSave)return;}
  else{const next=acceptGuideReviewStage(reviewDraft,guide,stage);if(!await persistReview(next))return;}
  const index=STAGES.indexOf(stage);if(index<STAGES.length-1){setStage(STAGES[index+1]);onNavigationChange?.({deviceId,stage:STAGES[index+1]});}
 }catch(error:any){setMessage(error.message);}};
 const displayedLessons=Array.isArray(sys.lessonsLearnedItems)?sys.lessonsLearnedItems:legacyLessons();
 const lessonCount=displayedLessons.map(normalizeLesson).filter(isLessonPopulated).length;
 const currentShipLessonReviews=lessonReviewCounts(displayedLessons.map(normalizeLesson).filter(isLessonPopulated),project.id);
 const importLesson=async(row:any)=>{
  if(!isAdmin||editingSection!=='lessons')return false;
  const next=[...lessonDraft,{id:uid(),...row,text:'',checked:false}];
  if(await update({...sys,...serializeLessons(next)})){
   setLessonDraft(next);setEditingSection(null);return true;
  }
  return false;
 };
 const saveCurrentShipLessonReview=async(id:string,values:any)=>{
  if(!isAdmin||editingSection||pending.current)return false;
  const items=legacyLessons().map(normalizeLesson);
  const idx=items.findIndex((item:any)=>item.id===id);
  if(idx<0)throw new Error('The lesson no longer exists. Refresh and try again.');
  const updated=setLessonReview(items[idx],project.id,values);
  if(updated===items[idx])return true;
  const next=items.map((item:any,index:number)=>index===idx?updated:item);
  return update({...sys,...serializeLessons(next)});
 };
 const applyExcelImport=async(parsed:any)=>{
  if(!isAdmin||editingSection||pending.current)return false;
  const next=applyGuideExcelImport(sys,beginGuideEdit(sys),parsed,uid);
  if(!String(next.name||'').trim()){setMessage('System name is required.');return false;}
  if(next.guideDraft?.technicalSnapshot?.os!==guideTechnicalValues(sys).os && (sys.deviceRuns||[]).some((r:any)=>!r.archived)){
   setMessage('Platform changes require a new endpoint profile when active device runs exist.');return false;
  }
  const saved=await update(next);
  if(saved){setShowExcelImport(false);setDraft(next.guideDraft);setIdentity(guideIdentity(next));}
  return saved;
 };
 const editControls=(section:string)=>editingSection===section?<div className="nb41-inline-actions"><B primary disabled={saving} onClick={saveSection}><Check size={15}/> Save</B><B disabled={saving} onClick={cancelEdit}>Cancel</B></div>:null;
 const editing=!!editingSection;
 return <section className="nb-guide-page nb40-guide-page nb41-guide-page">
  <header className="nb-page-header"><div><h1>{editing?identity.name:sys.name}</h1><p>System configuration guide · {deviceModelValue(technicalValues)||technicalValues.deviceCategory||'Device'} · {[technicalValues.os,technicalValues.osVersion].filter(Boolean).join(' ')}</p></div><div className="nb-actions">{isAdmin&&!editing&&<B className="nb75-import-button" onClick={()=>setShowExcelImport(true)}><ClipboardCheck size={16}/> Import from Excel</B>}{url&&<a className="nb-button nb88-guide-documentation" href={url} target="_blank" rel="noopener noreferrer" title="Open system documentation in a new tab"><FileText size={18} strokeWidth={2} aria-hidden="true"/><span>Documentation</span><ExternalLink size={14} strokeWidth={2} aria-hidden="true"/></a>}<B onClick={close}><ChevronLeft size={18} aria-hidden="true"/>Back to systems</B></div></header>
  {showExcelImport&&<GuideExcelImportModal busy={saving} onClose={()=>setShowExcelImport(false)} onApply={applyExcelImport}/> }
  <div className="nb-guide-body">
   <section className="nb-technical">
    <button type="button" className="nb-section-toggle" onClick={()=>setTechnical(v=>!v)} aria-expanded={technical}><span>Technical essentials</span><span>{technical?'Collapse':'Expand'}</span></button>
    {technical&&<GuideTechnicalReadout values={technicalValues} deviceVisualType={registryVisualType({...sys,guideDraft:{technicalSnapshot:{...technicalValues,deviceCategory:technicalValues.deviceCategory||sys.deviceCategory}}})} editingSection={editingSection} isAdmin={isAdmin&&!editing} field={inlineField} identityName={identity.name} onNameChange={(v:string)=>setMeta('name',v)} documentationUrl={identity.documentationUrl} onDocumentationChange={(v:string)=>setMeta('documentationUrl',v)} onEdit={beginEdit} onSave={saveSection} onCancel={cancelEdit} saving={saving}/>}
   </section>
   <GuideApplications value={technicalValues.appList} isAdmin={isAdmin&&!editing} editing={editingSection==='applications'} onEdit={()=>beginEdit('applications')} onChange={(v:string)=>setTech('appList',v)} onSave={saveSection} onCancel={cancelEdit} saving={saving}/>
   <details className={'nb-lessons nb41-lessons nb74-lessons nb79-lessons '+(!lessonCount?'nb-neutral':'')} open={editingSection==='lessons'?true:undefined}>
    <summary><BookOpen size={22} aria-hidden="true"/><strong>Lessons Learned</strong><span className="nb79-lesson-total">· {lessonCount?`${lessonCount} lesson${lessonCount===1?'':'s'}`:'No notes recorded'}</span>{lessonCount>0&&<span className="nb78-review-summary nb79-review-summary" aria-label="Current ship review summary"><span>{currentShipLessonReviews.confirmed} confirmed</span><span className="nb79-review-summary-dot" aria-hidden="true">·</span><span>{currentShipLessonReviews.pending} pending</span><span className="nb79-review-summary-dot" aria-hidden="true">·</span><span>{currentShipLessonReviews['in-progress']} in progress</span></span>}<ChevronDown size={19} className="nb-lessons-chevron"/></summary>
    <LessonsLearnedBody items={displayedLessons} editing={editingSection==='lessons'} draft={lessonDraft.map(normalizeLesson)} onDraftChange={setLessonDraft} onImportSave={importLesson} onSave={saveSection} onCancel={cancelEdit} saving={saving} projectId={project.id} canReview={isAdmin&&!editing} onReviewSave={saveCurrentShipLessonReview}/>
    {isAdmin&&!editing&&<button type="button" className="nb41-edit-pencil nb41-lesson-pencil" aria-label="Edit Lessons Learned" title="Edit lessons" onClick={()=>beginEdit('lessons')}><Pencil size={16}/></button>}
   </details>
   <section className="nb-config-workspace" aria-label="Configuration checklists">
    <div className="nb-config-header"><h2>Configuration checklist</h2><div className="nb41-config-tools"><span>{run?'Device verification': 'Guide verification'} · {marked} / {previewItems.length} checked</span>{isAdmin&&!editing&&<button type="button" className="nb41-edit-pencil" title="Edit checklist steps" aria-label="Edit Configuration Checklist" onClick={()=>beginEdit('checklist')}><Pencil size={16}/></button>}</div></div>
    <div className="nb-stage-tabs nb41-stage-arrows" role="group" aria-label="Configuration stages">{STAGES.map((s:string,i:number)=><button type="button" aria-pressed={stage===s} className={stage===s?'selected':''} key={s} onClick={()=>{setStage(s);onNavigationChange?.({deviceId,stage:s});}}><span>{i+1}</span>{LABELS[s]}{reviewRun?.accepted?.[s]?' ✓':''}</button>)}</div>
    {guide?.preparationEnabled&&<details className="nb-panel"><summary>0 Preparation · Optional</summary>{(guide.preparationItems||[]).map((item:any)=><label className="nb-check-row" key={item.id}><input type="checkbox" disabled={!isAdmin||!run||editing} checked={!!run?.checks?.[item.id]} onChange={e=>updateRun({...run,checks:{...run.checks,[item.id]:e.target.checked}})}/>{item.label}</label>)}</details>}
    {isAdmin&&<Migration sys={sys} run={run} onSave={update}/>}
    <section className="nb-checklist">
      <div className="nb-section-heading"><h2>{LABELS[stage]}</h2><span>{marked} / {previewItems.length} checked</span></div>
      {previewItems.length===0&&<p className="nb-empty">No reviewed steps in this stage. Use the pencil icon to add steps.</p>}
      {previewItems.map((item:any,i:number)=><div className={'nb-check-row'+(editingSection==='checklist'?' nb41-step-editor':'')} key={item.id}>
        {editingSection==='checklist'?<><input aria-label={'Step '+(i+1)} value={item.label} onChange={e=>setDraft({...draft,stages:{...draft.stages,[stage]:items.map((x:any)=>x.id===item.id?{...x,label:e.target.value}:x)}})}/><label><input type="checkbox" checked={item.required!==false} onChange={e=>setDraft({...draft,stages:{...draft.stages,[stage]:items.map((x:any)=>x.id===item.id?{...x,required:e.target.checked}:x)}})}/>Required</label><label><input type="checkbox" checked={!!item.allowNA} onChange={e=>setDraft({...draft,stages:{...draft.stages,[stage]:items.map((x:any)=>x.id===item.id?{...x,allowNA:e.target.checked}:x)}})}/>Allow N/A</label><label><input type="checkbox" checked={!!item.evidenceRequired} onChange={e=>setDraft({...draft,stages:{...draft.stages,[stage]:items.map((x:any)=>x.id===item.id?{...x,evidenceRequired:e.target.checked}:x)}})}/>Evidence</label><B disabled={i===0} onClick={()=>{const reordered=[...items];[reordered[i-1],reordered[i]]=[reordered[i],reordered[i-1]];setDraft({...draft,stages:{...draft.stages,[stage]:reordered}});}}>↑</B><B aria-label={'Remove step '+(i+1)} onClick={()=>setDraft({...draft,stages:{...draft.stages,[stage]:items.filter((x:any)=>x.id!==item.id)}})}><Trash2 size={15}/></B></>:
        <label className="nb41-check-label"><input type="checkbox" aria-label={item.label} checked={!!reviewRun.checks?.[item.id]} disabled={!isAdmin||saving||!!editingSection||!STAGES.slice(0,STAGES.indexOf(stage)).every(s=>!!reviewRun.accepted?.[s])} onChange={e=>markCheck(item,e.target.checked)}/><span>{item.label}<small>{item.required===false?'Optional':''}</small></span></label>}
        {editingSection!=='checklist'&&run&&<details className="nb-result-details"><summary>Result details</summary><p>{run.results?.[item.id]?.state||'pending'}{run.results?.[item.id]?.reason?' · '+run.results[item.id].reason:''}</p><p>{run.results?.[item.id]?.evidenceReference||'No evidence reference'}</p>{isAdmin&&<B onClick={()=>{const evidence=prompt('Evidence reference (text only, no upload)',run.results?.[item.id]?.evidenceReference||'');if(evidence===null)return;const reason=item.allowNA?prompt('N/A reason, or leave empty for completed',run.results?.[item.id]?.reason||''):'';if(reason===null)return;try{updateRun(setResult(run,stage,item.id,{state:reason?.trim()?'not_applicable':run.checks[item.id]?'completed':'pending',reason:reason||'',evidenceReference:evidence}));}catch(e:any){setMessage(e.message);}}}>Record evidence / N/A</B>}</details>}
       </div>)}
      {editingSection==='checklist'&&<>
       <div className="nb41-check-edit-footer"><B onClick={()=>setDraft({...draft,stages:{...draft.stages,[stage]:[...items,{id:uid(),label:'',required:true}]}})}><Plus size={15}/> Add step</B>{editControls('checklist')}<B disabled={saving} onClick={publish}>Publish reviewed guide</B></div>
       <details className="nb-panel"><summary>Preparation settings · optional</summary><label><input type="checkbox" checked={!!draft.preparationEnabled} onChange={e=>setDraft({...draft,preparationEnabled:e.target.checked})}/> Enable Preparation</label>{draft.preparationEnabled&&<textarea aria-label="Preparation items, one per line" value={(draft.preparationItems||[]).map((i:any)=>i.label).join('\n')} onChange={e=>setDraft({...draft,preparationItems:e.target.value.split('\n').map((label:string,i:number)=>({id:draft.preparationItems?.[i]?.id||uid(),label,required:false}))})}/>}</details>
       {onDeleteSystem&&<details className="nb41-destructive"><summary>Advanced</summary><B className="nb-guide-delete-btn" onClick={()=>{if(confirm('Delete this system AND its entire device and guide history? This cannot be undone. Export a backup first.'))onDeleteSystem(sys.id);}}>Delete system</B></details>}
      </>}
      {editingSection!=='checklist'&&<div className="nb-guide-footer"><B disabled={stage===STAGES[0]} onClick={()=>{const next=STAGES[STAGES.indexOf(stage)-1];setStage(next);onNavigationChange?.({deviceId,stage:next});}}><ChevronLeft size={16}/> Previous stage</B><div className="nb41-check-save-actions">{!run&&<B disabled={!isAdmin||!reviewDirty||saving||!!editingSection} onClick={()=>persistReview()}>Save checks</B>}<B primary disabled={!isAdmin||saving||!!editingSection||!canAccept(reviewRun,stage)} onClick={acceptCurrentStage}>Accept {LABELS[stage]}{stage!==STAGES[2]?' and continue':''} <ChevronRight size={16}/></B></div></div>}
    </section>
   </section>
   <p role="status" className="nb-save-state">{message}</p>
  </div>
 </section>;
}
/** The only non-guide form: minimal creation of a new system. All technical
 * information is subsequently maintained through Guide > Edit guide. */
export function SystemCreate({sys,project,isAdmin,onSave,onClose}:any){
 const [name,setName]=useState(sys.name||'');
 const [description,setDescription]=useState(sys.description||'');
 const [category,setCategory]=useState(sys.deviceCategory||'App only');
 const [assigneeId,setAssigneeId]=useState(sys.assigneeId||'');
 const [busy,setBusy]=useState(false),[error,setError]=useState('');
 const create=async()=>{if(!name.trim()){setError('Enter a system name.');return;}if(!isAdmin)return;
  const snapshot={...Object.fromEntries(TECH_FIELDS.map(k=>[k,sys[k]??''])),deviceCategory:category,deviceModel:'',deviceType:''};
  const next={...sys,name:name.trim(),description,deviceCategory:category,assigneeId,
   guideDraft:{...newGuide(),technicalSnapshot:snapshot}};
  setBusy(true);try{await onSave(next);}catch(e:any){setError(e.message)}finally{setBusy(false);}
 };
 return <section className="nb-editor-page nb-new-system-page"><div className="nb-breadcrumb">Systems / New system</div><header className="nb-page-header"><div><h1>Add system</h1><p>Create a system, then configure it directly in its guide.</p></div><B onClick={onClose}>Back to systems</B></header>
 <form className="nb-new-system-form" onSubmit={e=>{e.preventDefault();create();}}>
  <label>System name<input aria-label="System name" autoFocus value={name} onChange={e=>setName(e.target.value)} required/></label>
  <label>Device type<select value={category} onChange={e=>setCategory(e.target.value)} aria-label="Device type">{DEVICE_TYPES.map(t=><option key={t} value={t}>{t}</option>)}</select></label>
  <label>Deployment owner<select value={assigneeId} onChange={e=>setAssigneeId(e.target.value)}><option value="">Unassigned</option>{project.members.map((m:any)=><option key={m.id} value={m.id}>{m.name}</option>)}</select></label>
  <label>Description<textarea value={description} onChange={e=>setDescription(e.target.value)} rows={3}/></label>
  {error&&<p role="alert">{error}</p>}
  <div className="nb-new-system-actions"><button className="nb-button nb-primary" disabled={!isAdmin||busy} type="submit">{busy?'Creating…':'Create and open guide'}</button><B onClick={onClose}>Cancel</B></div>
 </form></section>;
}

/** Fast status controls save the shared Task ID, not one local assignment copy. */
/** Actions stay in this drawer. No standalone Edit task screen. */
function QuickAssignmentRow({task,number,isAdmin,project,sourceWeek,onQuickTaskSave,onQuickTaskEdit,onQuickTaskDelete,onQuickTaskMove,onRequireEdit}:any){
 const [saving,setSaving]=useState(false),[error,setError]=useState(''),[showBlocker,setShowBlocker]=useState(false),[blockReason,setBlockReason]=useState(task.blockReason||'');
 const [menuOpen,setMenuOpen]=useState(false),[editing,setEditing]=useState(false);
 const [draft,setDraft]=useState({label:task.label});
 const menuRef=useRef<HTMLDivElement|null>(null);
 useEffect(()=>{if(!menuOpen)return;const close=(event:MouseEvent)=>{if(menuRef.current&&!menuRef.current.contains(event.target as Node))setMenuOpen(false);};const key=(event:KeyboardEvent)=>{if(event.key==='Escape'){event.stopPropagation();setMenuOpen(false);}};document.addEventListener('pointerdown',close as any);document.addEventListener('keydown',key);return()=>{document.removeEventListener('pointerdown',close as any);document.removeEventListener('keydown',key);};},[menuOpen]);
 const commit=async(callback:()=>Promise<any>)=>{if(saving)return;setSaving(true);setError('');try{await callback();setMenuOpen(false);setEditing(false);}catch(e:any){setError(e?.message||'Could not save changes.');}finally{setSaving(false);}};
 const save=async(status:string,reason='')=>{if(!isAdmin||saving)return;await commit(async()=>{await onQuickTaskSave(task.id,{status,...(status==='Blocked'?{blockReason:reason}:{})});setShowBlocker(false);});};
 const actualStatus=task.status||'Planned';
 return <article className={'nb-quick-task-card nb-drawer-task nb-drawer-task-'+String(actualStatus).toLowerCase().replace(' ','-')+(menuOpen?' nb-menu-open':'')}>
  <div className="nb-drawer-task-index" aria-hidden="true">{String(number).padStart(2,'0')}</div>
  <div className="nb-drawer-task-content">
   <div className="nb-quick-task-header">
    <strong title={task.assignmentOwnerLabel?`System Owner: ${task.assignmentOwnerLabel}`:undefined}>{task.label}</strong>
    {<div className="nb-task-action-anchor" ref={menuRef}>
     <button type="button" className="nb-quick-advanced nb-drawer-more" aria-label={'More options for '+task.label} title="Task actions" aria-haspopup="menu" aria-expanded={menuOpen} onClick={()=>setMenuOpen(!menuOpen)}><MoreVertical size={20} aria-hidden="true"/></button>
     {menuOpen&&<div className="nb-task-action-menu" role="menu" aria-label={'Actions for '+task.label}>
      <button role="menuitem" type="button" onClick={()=>{if(!isAdmin){setMenuOpen(false);onRequireEdit();return;}setDraft({label:task.label});setEditing(true);setMenuOpen(false);}}><Pencil size={15}/> Edit</button>
      <button role="menuitem" type="button" disabled={saving||sourceWeek===0} onClick={()=>{setMenuOpen(false);if(!isAdmin){onRequireEdit();return;}void commit(()=>onQuickTaskMove(task.id,sourceWeek,'previous'));}}><ChevronLeft size={15}/> Move to previous week</button>
      <button role="menuitem" type="button" disabled={saving||sourceWeek>=519} onClick={()=>{setMenuOpen(false);if(!isAdmin){onRequireEdit();return;}void commit(()=>onQuickTaskMove(task.id,sourceWeek,'next'));}}><ChevronRight size={15}/> Move to next week</button>
      <button role="menuitem" type="button" className="nb-task-delete-action" disabled={saving} onClick={()=>{setMenuOpen(false);if(!isAdmin){onRequireEdit();return;}if(window.confirm(`Delete “${task.label}” permanently?\n\nThis removes this task and its history from all scheduled weeks. This cannot be undone.`))void commit(()=>onQuickTaskDelete(task.id));}}><Trash2 size={15}/> Delete</button>
     {!isAdmin&&<p className="nb-task-action-view-note">Sign in as Admin to make changes.</p>}
     </div>}
    </div>}
   </div>
   {editing&&isAdmin?<form className="nb-inline-task-editor" aria-label={'Edit '+task.label} onSubmit={e=>{e.preventDefault();void commit(()=>onQuickTaskEdit(task.id,{label:draft.label}));}}>
    <label>Task title<input required maxLength={160} autoFocus value={draft.label} disabled={saving} onChange={e=>setDraft({label:e.target.value})}/></label>
    <div className="nb-inline-task-buttons"><button type="submit" disabled={saving||!draft.label.trim()}>{saving?'Saving…':'Save changes'}</button><button type="button" disabled={saving} onClick={()=>setEditing(false)}>Cancel</button></div>
   </form>:<div className="nb-quick-task-toolbar"><label className="nb-quick-status-label">Status
    <select aria-label={'Status for '+task.label} value={showBlocker?'Blocked':actualStatus} disabled={!isAdmin||saving} onChange={e=>{const status=e.target.value;if(status==='Blocked'&&!(task.blockReason||'').trim()){setShowBlocker(true);return;}void save(status,task.blockReason||'');}}>
     <option value="Planned">Planned</option><option value="In Progress">Active</option><option value="Completed">Done</option><option value="Blocked">Blocked</option>
    </select>
   </label></div>}
   {showBlocker&&<form className="nb-quick-reason-form" onSubmit={e=>{e.preventDefault();if(blockReason.trim())void save('Blocked',blockReason.trim());}}><label>Reason for blocking<input autoFocus maxLength={2000} value={blockReason} disabled={saving} onChange={e=>setBlockReason(e.target.value)} placeholder="What is blocking this task?" required/></label><div><button type="submit" disabled={saving||!blockReason.trim()}>{saving?'Saving…':'Save blocker'}</button><button type="button" disabled={saving} onClick={()=>setShowBlocker(false)}>Cancel</button></div></form>}
   {task.assignmentOwnerLabel&&<p className="nb52-task-owner">System Owner: <strong>{task.assignmentOwnerLabel}</strong></p>}
   {actualStatus==='Blocked'&&task.blockReason&&<p className="nb-quick-block-reason">{task.blockReason}</p>}
   {saving&&<span role="status" className="nb-quick-saving">Saving…</span>}
   {error&&<p role="alert" className="nb-quick-error">{error}</p>}
  </div>
 </article>;
}

export function Tracker({project,isAdmin,canConfigureProject,onAuth,onQuickTaskEdit,onQuickTaskDelete,onQuickTaskMove,onMilestoneSave,onMilestoneDelete,onProjectStartChange,onQuickTaskSave,onQuickTaskCreate,onMemberRename,onMemberCreate,onMemberDelete,week,setWeek}:any){
 const [query,setQuery]=useState(''),[status,setStatus]=useState(''),[person,setPerson]=useState(''),[selected,setSelected]=useState<any>(null),[detail,setDetail]=useState<any>(null);
 // Legacy shared URLs with ?view=list now open the only supported Overview layout.
 useEffect(()=>{
  const url=new URL(location.href);
  if(!url.searchParams.has('view'))return;
  url.searchParams.delete('view');
  window.history.replaceState({nbdt:true},'',url.pathname+url.search+url.hash);
 },[]);
 // The left edge of the 4-week viewport is provided as `week` by the app.
 // Selection is independent. Selecting a week MUST NOT shift the viewport.
 const [selectedWeek,setSelectedWeek]=useState<number>(()=>{
  const requested=new URLSearchParams(location.search).get('selectedWeek');
  const parsed=weekIndexFromIso(project.startDate,requested);
  const legacyWeek=weekIndexFromIso(project.startDate,new URLSearchParams(location.search).get('week'));
  return parsed!==null?parsed:(legacyWeek!==null&&legacyWeek>clampWeekViewport(legacyWeek)?legacyWeek:week);
 });
 const selectWeek=(w:number)=>{
  const next=Math.max(0,Math.min(519,Math.trunc(w)));
  setSelectedWeek(next);
  const url=new URL(location.href);
  url.searchParams.set('selectedWeek',String(next+1));
  window.history.replaceState({nbdt:true},'',url.pathname+url.search);
 };
 // Restore selection from share URLs. Changing projects or the calendar anchor
 // intentionally reselects the actual current project week, without allowing an
 // old query parameter to pin a now-unrelated week.
 const anchorRef=useRef({projectId:project.id,startDate:project.startDate});
 useEffect(()=>{
  const anchorChanged=anchorRef.current.projectId!==project.id||anchorRef.current.startDate!==project.startDate;
  anchorRef.current={projectId:project.id,startDate:project.startDate};
  const requested=anchorChanged?null:new URLSearchParams(location.search).get('selectedWeek');
  const parsed=weekIndexFromIso(project.startDate,requested);
  const freshCurrent=currentWeekIndex(project.startDate,project.timezone||'Europe/Paris');
  const legacyWeek=weekIndexFromIso(project.startDate,new URLSearchParams(location.search).get('week'));
  const pinnedSelection=legacyWeek!==null&&legacyWeek>clampWeekViewport(legacyWeek)?legacyWeek:week;
  setSelectedWeek(parsed!==null?parsed:(anchorChanged?Math.max(0,Math.min(519,freshCurrent??0)):pinnedSelection));
 },[project.id,project.startDate]);
 const [editingMemberId,setEditingMemberId]=useState<string|null>(null);
 const [memberDraft,setMemberDraft]=useState('');
 const [addingMember,setAddingMember]=useState(false);
 const [newMemberName,setNewMemberName]=useState('');
 const [memberBusy,setMemberBusy]=useState(false);
 const [memberError,setMemberError]=useState('');
 const [memberToDelete,setMemberToDelete]=useState<string|null>(null);
 const memberDialogRef=useRef<HTMLElement|null>(null);
 // A milestone is an independent project record. The editor is deliberately
 // light-weight and does not alter the surrounding tracker or its scroll state.
 const [milestoneEditor,setMilestoneEditor]=useState<any>(null);
 const [milestoneDraft,setMilestoneDraft]=useState('');
 const [milestoneBusy,setMilestoneBusy]=useState(false);
 const [milestoneError,setMilestoneError]=useState('');
 const [expandedMilestoneWeek,setExpandedMilestoneWeek]=useState<number|null>(null);
 const [showMobileMatrix,setShowMobileMatrix]=useState(false);
 const [todayDate,setTodayDate]=useState(()=>todayInTimezone(project.timezone||'Europe/Paris'));
 const [dateSaving,setDateSaving]=useState(false);
 const [addingAssignment,setAddingAssignment]=useState(false),[newAssignment,setNewAssignment]=useState(''),[quickAdding,setQuickAdding]=useState(false),[quickError,setQuickError]=useState(''),[quickNotice,setQuickNotice]=useState('');
 const newAssignmentList=parseClipboardAssignments(newAssignment);
 const invalidTaskIndex=newAssignmentList.findIndex(label=>label.length>160);
 const canAddAssignments=newAssignmentList.length>0&&newAssignmentList.length<=100&&invalidTaskIndex<0;
 const panelRef=useRef<HTMLElement|null>(null);
 const panelTriggerRef=useRef<HTMLElement|null>(null);
 const tableScrollRef=useRef<HTMLDivElement|null>(null);
 const weekFooterScrollRef=useRef<HTMLDivElement|null>(null);
 const weekFooterGridRef=useRef<HTMLDivElement|null>(null);
 // One-way scroll mirroring only: the footer is a display of the matrix columns,
 // never a second independent scroll control that can fight the week arrows.
 // The footer is deliberately NOT a scroll container: two nested native
 // scrollbars used to show extra system arrows over the Next/Today controls.
 // On narrow screens mirror the task grid via a visual transform only.
 const syncWeekScroll=()=>{
  const table=tableScrollRef.current,footer=weekFooterScrollRef.current;
  const cards=footer?.querySelector<HTMLElement>('.nb-week-card-grid');
  if(table&&cards)cards.style.transform=`translate3d(${-table.scrollLeft}px,0,0)`;
 };
 // Match footer tracks to the actual rendered table columns, not estimates.
 // Borders, resized sidebars and fractional browser pixels can otherwise produce
 // visible drift in later week cards. A single resize measurement is authoritative.
 useEffect(()=>{
  const table=tableScrollRef.current?.querySelector<HTMLTableElement>('.nb-week-grid');
  const footerGrid=weekFooterGridRef.current;
  if(!table||!footerGrid)return;
  const update=()=>{
   const headers=Array.from(table.querySelectorAll<HTMLTableCellElement>('thead tr > th'));
   if(headers.length!==5)return;
   const tracks=headers.map(cell=>cell.getBoundingClientRect().width);
   if(tracks.some(value=>value<1))return; // Hidden mobile matrix: keep the fallback grid.
   footerGrid.style.setProperty('grid-template-columns',tracks.map(value=>`${value}px`).join(' '),'important');
   footerGrid.style.setProperty('width',`${tracks.reduce((total,value)=>total+value,0)}px`,'important');
   // One scroll owner: the matrix. Footer follows without a native scrollbar.
   const left=tableScrollRef.current?.scrollLeft||0;
   footerGrid.style.transform=`translate3d(${-left}px,0,0)`;
  };
  update();
  const observer=typeof ResizeObserver==='undefined'?null:new ResizeObserver(update);
  observer?.observe(table);
  const headers=table.querySelectorAll('thead th');
  headers.forEach(header=>observer?.observe(header));
  window.addEventListener('resize',update);
  return()=>{observer?.disconnect();window.removeEventListener('resize',update);};
 },[project.id,showMobileMatrix]);
 const resetWeekScroll=()=>{
  if(tableScrollRef.current)tableScrollRef.current.scrollLeft=0;
  if(weekFooterScrollRef.current)weekFooterScrollRef.current.scrollLeft=0;
  const cards=weekFooterScrollRef.current?.querySelector<HTMLElement>('.nb-week-card-grid');
  if(cards)cards.style.transform='translate3d(0px,0,0)';
 };
 const navigateWeek=(direction:number)=>{
  const next=moveWeekViewport(week,direction);
  if(next===week)return;
  // Move one project-week viewport; never request browser/scrollbar navigation.
  resetWeekScroll();
  setWeek(next);
 };
 const closeQuickPanel=()=>{
  if(quickAdding)return;
  if(addingAssignment&&newAssignment.trim()&&!window.confirm('Discard unsaved assignment?'))return;
  setSelected(null);setDetail(null);setAddingAssignment(false);setNewAssignment('');setQuickError('');setQuickNotice('');
 };
 const openQuickPanel=(personId:string,w:number,task:any=null)=>{
  if(!selected&&document.activeElement instanceof HTMLElement)panelTriggerRef.current=document.activeElement;
  setSelected({id:personId,week:w});setDetail(task);setAddingAssignment(false);setNewAssignment('');setQuickError('');setQuickNotice('');
 };
 // The overlay must not resize the matrix; preserve focus and keyboard access.
 useEffect(()=>{
  if(!selected){const target=panelTriggerRef.current;panelTriggerRef.current=null;if(target?.isConnected)target.focus();return;}
  panelRef.current?.focus();
 },[selected?.id,selected?.week]);
 useEffect(()=>{
  if(!selected)return;
  const onKeyDown=(event:KeyboardEvent)=>{
   if(event.key==='Escape'){event.preventDefault();closeQuickPanel();return;}
   if(event.key!=='Tab'||!panelRef.current)return;
   const controls=Array.from(panelRef.current.querySelectorAll<HTMLElement>('button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')).filter(el=>el.getClientRects().length>0);
   if(!controls.length){event.preventDefault();panelRef.current.focus();return;}
   const first=controls[0],last=controls[controls.length-1];
   if(event.shiftKey&&(document.activeElement===first||document.activeElement===panelRef.current)){event.preventDefault();last.focus();}
   else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  };
  window.addEventListener('keydown',onKeyDown);
  return()=>window.removeEventListener('keydown',onKeyDown);
 },[selected?.id,selected?.week,addingAssignment,newAssignment,quickAdding]);

 useEffect(()=>{const tick=()=>setTodayDate(todayInTimezone(project.timezone||'Europe/Paris'));tick();const timer=window.setInterval(tick,60000);return()=>clearInterval(timer);},[project.timezone]);
 const actualCurrentWeek=weekIndexFromDate(project.startDate,todayDate);
 const currentWeek=actualCurrentWeek===null?-1:actualCurrentWeek;
 const milestoneTone=(ms:any)=>/freeze|block|critical/i.test(ms.label)?'critical':/qa|testing|review|inspection/i.test(ms.label)?'review':/handover|final|complete|launch/i.test(ms.label)?'complete':'standard';
 // Calendar month/year navigation is entirely local to the picker.
 // Only the explicit Apply date button reaches this persistence function; no browser confirm per navigation step.
 const updateStart=async(value:string)=>{if(dateSaving||value===project.startDate)return;if(!validDate(value))throw Error('Choose a valid date.');setDateSaving(true);try{await onProjectStartChange(value);}finally{setDateSaving(false);}};
 const tasks=project.tasks.filter((t:any)=>!t.isMilestone).map((t:any)=>({...t,status:effectiveStatus(t,project.issues)}));
 const milestones=project.tasks.filter((t:any)=>t.isMilestone).sort((a:any,b:any)=>a.startWeek-b.startWeek||String(a.label).localeCompare(String(b.label)));
 const matches=(t:any)=>(!status||t.status===status)&&(!person||assignments(t).includes(person))&&(!query||(t.label+' '+assignments(t).map((id:string)=>project.members.find((m:any)=>m.id===id)?.name||'').join(' ')).toLowerCase().includes(query.toLowerCase()));
 const at=(id:string,w:number)=>tasks.filter((t:any)=>(id===UNASSIGNED_MEMBER_ID?(!t.memberId||!project.members.some((m:any)=>m.id===t.memberId)):assignments(t).includes(id))&&t.startWeek<=w&&t.startWeek+t.duration>w&&matches(t));
 // Keep historic assignments visible after a member is removed.
 const orphaned=(t:any)=>!t.memberId||!project.members.some((m:any)=>m.id===t.memberId);
 const hasOrphans=tasks.some(orphaned);
 const unassignedPerson={id:UNASSIGNED_MEMBER_ID,name:'Unassigned'};
 const people=[...project.members.filter((m:any)=>!person||m.id===person),...(!person&&hasOrphans?[unassignedPerson]:[])];
 const weeks=Array.from({length:4},(_,i)=>clampWeekViewport(week)+i);
 const selectedPerson=people.find((m:any)=>m.id===selected?.id) || (selected?.id===UNASSIGNED_MEMBER_ID?unassignedPerson:undefined);
 const chosen=selected?at(selected.id,selected.week):[];
 const open=(t:any)=>setDetail(t);
 const selectedIsoWeek=`Week ${selectedWeek+1}`;
 const weekIso=(w:number)=>`Week ${w+1}`;
 const weekDate=(w:number)=>projectWeekDate(project.startDate,w);
 const milestonesAt=(w:number)=>milestones.filter((m:any)=>m.startWeek===w);
 const closestScheduledWeek=tasks.length?tasks.map((t:any)=>t.startWeek).sort((a:number,b:number)=>Math.abs(a-week)-Math.abs(b-week))[0]:null;
 const visibleWeeksHaveTasks=weeks.some(w=>tasks.some((t:any)=>t.startWeek<=w&&t.startWeek+t.duration>w&&matches(t)));
 const currentWeekTasks=tasks.filter((t:any)=>t.startWeek<=selectedWeek&&t.startWeek+t.duration>selectedWeek&&matches(t));
 const visibleRangeTasks=tasks.filter((t:any)=>t.startWeek<week+4&&t.startWeek+t.duration>week&&matches(t));
 const visibleRangeCount=new Set(visibleRangeTasks.map((t:any)=>t.id)).size;
 const currentWeekTaskCount=new Set(currentWeekTasks.map((t:any)=>t.id)).size;
 const blockedCount=new Set(currentWeekTasks.filter((t:any)=>t.status==='Blocked').map((t:any)=>t.id)).size;
 const totalAssignments=currentWeekTasks.length;
 const totalMilestones=weeks.reduce((n:number,w:number)=>n+milestonesAt(w).length,0);
 const editMilestone=(ms:any)=>{
  if(!isAdmin)return;
  setMilestoneEditor({...ms,creating:!project.tasks.some((task:any)=>task.id===ms.id)});
  setMilestoneDraft(ms.creating?'':String(ms.label||''));
  setMilestoneError('');setExpandedMilestoneWeek(null);
 };
 const createMilestone=(w:number)=>editMilestone({id:uid(),label:'',creating:true,startWeek:w,duration:1,status:'Planned',description:'',memberId:'milestones',isMilestone:true,date:weekDate(w)});
 const saveMilestone=async(event:React.FormEvent)=>{
  event.preventDefault();if(!milestoneEditor||milestoneBusy)return;
  const label=milestoneDraft.trim();if(!label||label.length>160){setMilestoneError('Milestone name must be 1–160 characters.');return;}
  setMilestoneBusy(true);setMilestoneError('');
  try{await onMilestoneSave(Object.fromEntries(Object.entries({...milestoneEditor,label}).filter(([key])=>key!=='creating')),milestoneEditor.id);setMilestoneEditor(null);}
  catch(error:any){setMilestoneError(error?.message||'Unable to save milestone.');}
  finally{setMilestoneBusy(false);}
 };
 const deleteMilestone=async()=>{
  if(!milestoneEditor||milestoneEditor.creating||milestoneBusy||!isAdmin)return;
  if(!window.confirm(`Delete milestone “${milestoneEditor.label}”? This cannot be undone.`))return;
  setMilestoneBusy(true);setMilestoneError('');
  try{await onMilestoneDelete(milestoneEditor.id);setMilestoneEditor(null);}
  catch(error:any){setMilestoneError(error?.message||'Unable to delete milestone.');}
  finally{setMilestoneBusy(false);}
 };
 useEffect(()=>{
  if(!milestoneEditor)return;
  const closeOnEscape=(event:KeyboardEvent)=>{
   if(event.key==='Escape'&&!milestoneBusy){event.preventDefault();setMilestoneEditor(null);}
  };
  document.addEventListener('keydown',closeOnEscape);
  return()=>document.removeEventListener('keydown',closeOnEscape);
 },[milestoneEditor,milestoneBusy]);
 const startMemberRename=(m:any)=>{setMemberError('');setAddingMember(false);setEditingMemberId(m.id);setMemberDraft(m.name);};
 const saveMemberRename=async(e:React.FormEvent)=>{e.preventDefault();if(memberBusy)return;setMemberError('');setMemberBusy(true);try{await onMemberRename(editingMemberId,memberDraft);setEditingMemberId(null);}catch(error:any){setMemberError(error?.message||'Could not rename team member.');}finally{setMemberBusy(false);}};
 const createMember=async(e:React.FormEvent)=>{e.preventDefault();if(memberBusy)return;setMemberError('');setMemberBusy(true);try{await onMemberCreate(newMemberName);setAddingMember(false);setNewMemberName('');}catch(error:any){setMemberError(error?.message||'Could not add team member.');}finally{setMemberBusy(false);}};
 // The trash icon only OPENS confirmation. No destructive write before approval.
 const deleteMember=(m:any)=>{
  if(memberBusy||!isAdmin||m.id===UNASSIGNED_MEMBER_ID)return;
  setMemberError('');setMemberToDelete(m.id);
 };
 const memberPendingDeletion=project.members.find((m:any)=>m.id===memberToDelete);
 const pendingOwnedTasks=memberPendingDeletion?project.tasks.filter((t:any)=>!t.isMilestone&&t.memberId===memberToDelete):[];
 const pendingHelperTasks=memberPendingDeletion?project.tasks.filter((t:any)=>!t.isMilestone&&t.memberId!==memberToDelete&&(t.helperIds||[]).includes(memberToDelete)):[];
 const pendingOwnedSystems=memberPendingDeletion?project.systems.filter((sys:any)=>sys.assigneeId===memberToDelete):[];
 const confirmMemberDelete=async()=>{
  const id=memberToDelete;
  if(memberBusy||!isAdmin||!id||!project.members.some((m:any)=>m.id===id))return;
  setMemberBusy(true);setMemberError('');
  try{
   await onMemberDelete(id);
   setMemberToDelete(null);
   if(person===id)setPerson('');
   if(selected?.id===id)closeQuickPanel();
   if(editingMemberId===id)setEditingMemberId(null);
  }catch(error:any){setMemberError(error?.message||'Could not delete this employee. Nothing was removed.');}
  finally{setMemberBusy(false);}
 };
 // Keep Escape available and focus on the safer Cancel button first.
 useEffect(()=>{
  if(!memberToDelete)return;
  const onKeyDown=(event:KeyboardEvent)=>{
   if(event.key==='Escape'&&!memberBusy){event.preventDefault();setMemberToDelete(null);return;}
   if(event.key==='Tab'&&memberDialogRef.current){
    const buttons=Array.from(memberDialogRef.current.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'));
    if(!buttons.length)return;
    const first=buttons[0],last=buttons[buttons.length-1];
    if(event.shiftKey&&(document.activeElement===first||!memberDialogRef.current.contains(document.activeElement))){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&(document.activeElement===last||!memberDialogRef.current.contains(document.activeElement))){event.preventDefault();first.focus();}
   }
  };
  window.addEventListener('keydown',onKeyDown);
  return()=>window.removeEventListener('keydown',onKeyDown);
 },[memberToDelete,memberBusy]);

 useEffect(()=>{if(!isAdmin){setEditingMemberId(null);setAddingMember(false);setMemberToDelete(null);setMemberError('');}},[isAdmin]);

 useEffect(()=>{setSelected(null);setDetail(null);},[week,project.id]);
 // openQuickPanel/closeQuickPanel own the quick-add lifecycle; do not reset an add opened from the toolbar.

 return <section className="nb-tracker" data-view="overview">
  <header className="nb-page-header nb45-primary-header">
   <div>
    <h1>Weekly Tracker</h1>
   </div>
  </header>

  <div className="nb-toolbar">
   <div className="nb-segments nb-overview-only-segment"><span className="nb-button nb-overview-only-tab" aria-current="page">Overview</span></div>
   <div className="nb-project-start"><ProjectStartPicker value={project.startDate} today={todayDate} hasTasks={project.tasks.length>0} disabled={!canConfigureProject} busy={dateSaving} onConfirm={updateStart}/></div>
   <select aria-label="Person filter" value={person} onChange={e=>setPerson(e.target.value)}><option value="">All people</option>{project.members.map((m:any)=><option key={m.id} value={m.id}>{m.name}</option>)}</select>
   <select aria-label="Status filter" value={status} onChange={e=>setStatus(e.target.value)}><option value="">All statuses</option>{['Planned','In Progress','Blocked','Completed'].map(v=><option key={v}>{v}</option>)}</select>
   <div className="nb-search-box"><Search size={18} aria-hidden="true"/><input aria-label="Search tasks or people" placeholder="Search tasks or people..." value={query} onChange={e=>setQuery(e.target.value)}/></div>
  </div>

  <div className="nb-summary">
   <div className="nb-summary-metrics">
    <span className="nb-summary-pill"><Users size={17} aria-hidden="true"/>{people.length} people</span>
    <span className="nb-summary-pill nb-selected-summary" title="Selection does not move the visible four-week window"><ClipboardCheck size={17} aria-hidden="true"/>{selectedIsoWeek} selected · {currentWeekTaskCount} unique tasks</span>
    <span className="nb-summary-pill nb-summary-blockers"><AlertCircle size={17} aria-hidden="true"/>{blockedCount} blocked in selected week</span>
    <span className="nb-summary-pill nb-visible-summary">Viewing Weeks {week+1}–{Math.min(520,week+4)} · {visibleRangeCount} unique tasks</span>
    {totalMilestones>0&&<span className="nb-summary-pill"><Flag size={17} aria-hidden="true"/>{totalMilestones} milestones in view</span>}
    {currentWeek>=week&&currentWeek<week+4&&<span className="nb-current-indicator">Current: Week {currentWeek+1}</span>}
   </div>
   <div className="nb-summary-actions">
    {(selectedWeek<week||selectedWeek>=week+4)&&<B className="nb-show-selected-week" onClick={()=>setWeek(clampWeekViewport(selectedWeek))}>Show selected Week {selectedWeek+1} →</B>}
    {!query&&!person&&!status&&closestScheduledWeek!==null&&!visibleWeeksHaveTasks&&<B onClick={()=>setWeek(clampWeekViewport(closestScheduledWeek))}>View scheduled assignments →</B>}
    <button type="button" className="nb-mobile-matrix-toggle nb-button" onClick={()=>setShowMobileMatrix(!showMobileMatrix)}>{showMobileMatrix?'By person':'Show matrix'}</button>
   </div>
  </div>

  <div className="nb-tracker-content">
   <div className="nb-tracker-table-wrap" ref={tableScrollRef} onScroll={syncWeekScroll}>
    <>
     <div className={'nb-mobile-week-cards '+(showMobileMatrix?'matrix-open':'')} aria-label="Assignments by person">
      {people.map((m:any)=>{
       const mobileList=at(m.id,week);
       const mobileMilestones=milestonesAt(week);
       return <section key={m.id} className="nb-mobile-person-card">
        <header>
         <span className="nb-avatar">{memberInitial(m.name)}</span>
         <span><strong>{m.name}</strong><small>{m.title||'Team member'}</small></span>
         <span className="nb-mobile-person-count">{mobileList.length} assignments</span>
         {isAdmin&&m.id!==UNASSIGNED_MEMBER_ID&&<div className="nb-member-actions"><button type="button" aria-label={`Rename ${m.name}`} onClick={()=>startMemberRename(m)}><Pencil size={15}/></button><button type="button" aria-label={`Remove ${m.name}`} onClick={()=>deleteMember(m)}><Trash2 size={15}/></button></div>}
        </header>
        {isAdmin&&editingMemberId===m.id&&<form className="nb-member-rename-form" onSubmit={saveMemberRename}><input autoFocus required maxLength={80} value={memberDraft} aria-label={`New name for ${m.name}`} onChange={e=>setMemberDraft(e.target.value)}/><button type="submit">Save</button><button type="button" onClick={()=>setEditingMemberId(null)}>Cancel</button></form>}
        <div className="nb-mobile-week-title">{weekIso(week)} · {weekRange(project.startDate,week)}</div>
        {!!mobileMilestones.length&&<div className="nb-mobile-milestones">{mobileMilestones.map((ms:any)=><button type="button" key={ms.id} className="nb-milestone-chip" onClick={()=>{if(isAdmin)editMilestone(ms);}}><span>{ms.label}</span>{ms.date&&<small>{ms.date}</small>}</button>)}</div>}
        {mobileList.length?mobileList.map((t:any)=><button key={t.id} className="nb-mobile-mini-task" onClick={()=>{selectWeek(week);openQuickPanel(m.id,week,t);}}><span>{t.label}{t.memberId!==m.id&&<small>Helper</small>}</span><Badge value={t.status}/></button>):<p className="nb-empty">No tasks planned</p>}
        <button type="button" className="nb-mobile-open-assignments" onClick={()=>{selectWeek(week);openQuickPanel(m.id,week);}}>View assignments →</button>
       </section>;
      })}
      {isAdmin&&<div className="nb-member-create-row nb-member-create-mobile">
       {!addingMember?<button type="button" className="nb-member-create-trigger" onClick={()=>{setAddingMember(true);setEditingMemberId(null);setMemberError('');}}><Plus size={17}/> Add team member</button>:<form className="nb-member-create-form" onSubmit={createMember}><input required autoFocus maxLength={80} aria-label="New team member name" placeholder="Name" value={newMemberName} onChange={e=>setNewMemberName(e.target.value)}/><button type="submit" disabled={memberBusy||!newMemberName.trim()}>Create</button><button type="button" onClick={()=>{setAddingMember(false);setNewMemberName('');}}>Cancel</button></form>}
       {memberError&&<p role="alert" className="nb-member-error">{memberError}</p>}
      </div>}
     </div>
     <table className={'nb-week-grid '+(!showMobileMatrix?'mobile-cards-preferred':'')} aria-label="Weekly assignments matrix">
      <thead>
       <tr>
        <th className="nb-employee-head">Employee</th>
        {weeks.map(w=>{const columnMilestones=milestonesAt(w);const tone=weekHeaderTone(w);return <th key={w} className={(currentWeek===w?'nb-current-week-column':'')+' nb-week-tone-'+tone}>
         <div className="nb-week-head">
          <div className="nb-week-head-top">
           <div className="nb-week-head-title"><button type="button" className="nb-week-header-label" aria-label={`Select ${weekIso(w)}`} aria-pressed={selectedWeek===w} onClick={()=>selectWeek(w)} title={`Select ${weekIso(w)}`}>{weekIso(w)}</button></div>
           <span className="nb-week-range-hint" aria-hidden="true"><CalendarDays size={17}/></span>
          </div>
          <div className={'nb-week-milestones nb-milestone-stack '+(columnMilestones.length>1?'nb-milestone-multiple ':'')+(expandedMilestoneWeek===w?'nb-milestone-expanded':'')}
               onMouseLeave={()=>setExpandedMilestoneWeek(previous=>previous===w?null:previous)}>
           {columnMilestones.length?columnMilestones.map((ms:any)=><div className="nb-milestone-entry" key={ms.id}>
             <button type="button" title={isAdmin?'Edit milestone':'Project milestone'}
              className={'nb-milestone-chip nb-ms-'+milestoneTone(ms)+' '+(isAdmin?'editable':'')}
              onClick={()=>isAdmin?editMilestone(ms):void 0}>
              <Flag size={15} fill="currentColor" aria-hidden="true"/><span>{ms.label}</span>
             </button>
             {isAdmin&&<button type="button" className="nb-milestone-edit" title={'Edit '+ms.label}
              aria-label={'Edit milestone '+ms.label} onClick={()=>editMilestone(ms)}><Pencil size={13} aria-hidden="true"/></button>}
            </div>):<span className="nb-milestone-empty">No milestone</span>}
           {columnMilestones.length>1&&<button type="button" className="nb-milestone-more"
             aria-label={`Show all ${columnMilestones.length} milestones in ${weekIso(w)}`}
             aria-expanded={expandedMilestoneWeek===w}
             onClick={()=>setExpandedMilestoneWeek(expandedMilestoneWeek===w?null:w)}>+{columnMilestones.length-1} more</button>}
           {isAdmin&&<button type="button" className="nb-milestone-add" aria-label={'Add milestone to '+weekIso(w)} title={'Add milestone to '+weekIso(w)} onClick={()=>createMilestone(w)}>+</button>}
          </div>

         </div>
        </th>})}
       </tr>
      </thead>
      <tbody>
       {people.map((m:any)=>{
        const hasAssignments=weeks.some(w=>at(m.id,w).length);
        return <tr key={m.id} className={hasAssignments?'nb-has-assignments':'nb-no-assignments'}>
         <th>
          <div className="nb-person-cell">
           <span className="nb-avatar">{memberInitial(m.name)}</span>
           <div className="nb-person-meta">
           <div className="nb-person-copy">
            {editingMemberId===m.id&&isAdmin?
             <form className="nb-member-rename-form" onSubmit={saveMemberRename}>
              <input aria-label={`New name for ${m.name}`} autoFocus maxLength={80} required value={memberDraft} disabled={memberBusy} onChange={e=>setMemberDraft(e.target.value)} onKeyDown={e=>{if(e.key==='Escape'){e.stopPropagation();setEditingMemberId(null);setMemberError('');}}}/>
              <button type="submit" aria-label={`Save ${m.name} name`} title="Save" disabled={memberBusy||!memberDraft.trim()}><Check size={16}/></button>
              <button type="button" aria-label="Cancel rename" title="Cancel" disabled={memberBusy} onClick={()=>{setEditingMemberId(null);setMemberError('');}}><X size={16}/></button>
             </form>:
             <><strong>{m.name}</strong>{m.title&&<small>{m.title}</small>}</>}
           </div>
           {isAdmin&&m.id!==UNASSIGNED_MEMBER_ID&&editingMemberId!==m.id&&<div className="nb-member-actions">
            <button type="button" title={`Rename ${m.name}`} aria-label={`Rename ${m.name}`} disabled={memberBusy} onClick={()=>startMemberRename(m)}><Pencil size={15}/></button>
            <button type="button" title={`Remove ${m.name}`} aria-label={`Remove ${m.name}`} disabled={memberBusy} onClick={()=>deleteMember(m)}><Trash2 size={15}/></button>
           </div>}
           </div>
          </div>
         </th>
         {weeks.map(w=>{
          const list=at(m.id,w);
          const blocked=list.filter((t:any)=>t.status==='Blocked').length;
          return <td key={w} className={(list.length?'nb-populated-week':'nb-empty-week')+(currentWeek===w?' nb-current-week-cell':'')}>
           <button aria-label={`${m.name}: ${list.length} assignments in ${weekIso(w)}`} className={'nb-week-cell '+(selected?.id===m.id&&selected?.week===w?'selected':'')} onClick={()=>{selectWeek(w);openQuickPanel(m.id,w);}}>
            <div className="nb-week-cell-head">
             <strong>{list.length?`${list.length} assignments`:'No tasks planned'}</strong>
             {blocked>0&&<span className="nb-week-blocked">{blocked} blocked</span>}
            </div>
            {list.slice(0,4).map((t:any)=><span className="nb-mini-task" key={t.id} title={t.assignmentOwnerLabel?`System Owner: ${t.assignmentOwnerLabel}`:undefined}><span>{t.label}</span><Badge value={t.status}/></span>)}
            {list.length>4&&<span className="nb-more">+{list.length-4} more · View all {list.length}</span>}
           </button>
          </td>;
         })}
        </tr>;
       })}
       {isAdmin&&<tr className="nb-member-create-table-row"><th>
        {!addingMember?<button type="button" className="nb-member-create-trigger" onClick={()=>{setAddingMember(true);setEditingMemberId(null);setMemberError('');}}><Plus size={17}/> Add team member</button>:
         <form className="nb-member-create-form nb-member-create-inline" onSubmit={createMember}>
          <input autoFocus required maxLength={80} aria-label="New team member name" placeholder="Name" value={newMemberName} disabled={memberBusy} onChange={e=>setNewMemberName(e.target.value)} onKeyDown={e=>{if(e.key==='Escape'){e.stopPropagation();setAddingMember(false);setNewMemberName('');setMemberError('');}}}/>
          <button type="submit" disabled={!newMemberName.trim()||memberBusy}>Create</button>
          <button type="button" disabled={memberBusy} onClick={()=>{setAddingMember(false);setNewMemberName('');setMemberError('');}}>✕</button>
         </form>}
        {memberError&&<p className="nb-member-error" role="alert">{memberError}</p>}
       </th><td colSpan={4} aria-hidden="true"/></tr>}
      </tbody>
     </table>
    </>
   </div>
  </div>

   {selected&&createPortal(<>
    <div className="nb-quick-overlay-backdrop" aria-hidden="true" onClick={closeQuickPanel}/>
    <aside ref={panelRef} tabIndex={-1} role="dialog" aria-modal="true" aria-label="Person assignments" className="nb-assignment-panel nb-quick-panel nb-overlay-panel nb-project-week-drawer">
    <header className={"nb-quick-panel-heading nb-week-tone-"+weekHeaderTone(selected.week)+(currentWeek===selected.week?" nb-drawer-current-week":"")}>
      <div className="nb-quick-person"><span className="nb-avatar">{memberInitial(selectedPerson?.name)}</span><div><h2>{selectedPerson?.name}</h2><p>{weekIso(selected.week)} · {weekRange(project.startDate,selected.week)}</p></div></div>
      <B aria-label="Close person panel" onClick={closeQuickPanel}><X size={22} aria-hidden="true"/></B>
    </header>
    <div className="nb-quick-metrics nb-drawer-stats" aria-label="Assignment status summary">
     <span className="nb-metric-active"><strong>{chosen.filter((t:any)=>t.status==='In Progress').length}</strong><small>Active</small></span>
     <span className="nb-metric-planned"><strong>{chosen.filter((t:any)=>t.status==='Planned').length}</strong><small>Planned</small></span>
     <span className="nb-metric-done"><strong>{chosen.filter((t:any)=>t.status==='Completed').length}</strong><small>Done</small></span>
     <span className="nb-metric-blocked"><strong>{chosen.filter((t:any)=>t.status==='Blocked').length}</strong><small>Blocked</small></span>
    </div>
    <div className="nb-drawer-section-heading nb-drawer-assignments-heading"><strong>Assignments</strong><span>{chosen.length}</span></div>
    {quickNotice&&<p className="nb-quick-success" role="status">{quickNotice}</p>}
    <div className="nb-quick-list" aria-label="Assignments for selected week">
     {chosen.length===0&&<p className="nb-quick-empty">No assignments for this person in {weekIso(selected.week)}.</p>}
     {chosen.map((t:any,index:number)=><QuickAssignmentRow key={t.id} number={index+1} task={t} project={project} sourceWeek={selected.week} isAdmin={isAdmin} onQuickTaskSave={onQuickTaskSave} onQuickTaskEdit={onQuickTaskEdit} onQuickTaskDelete={onQuickTaskDelete} onRequireEdit={onAuth} onQuickTaskMove={async(id:string,source:number,direction:'next'|'previous')=>{await onQuickTaskMove(id,source,direction);setQuickNotice(`Moved to Week ${source+(direction==='previous'?0:2)}`);}}/>)}
    </div>
    {isAdmin&&selected.id!==UNASSIGNED_MEMBER_ID?<div className="nb-quick-add-area">
     {!addingAssignment?<button type="button" className="nb-quick-add-button" onClick={()=>{setAddingAssignment(true);setQuickError('');}}><Plus size={19} aria-hidden="true"/> Add assignment</button>:<form className="nb-quick-add-form" onSubmit={async(e:any)=>{
      e.preventDefault();if(quickAdding)return;
      const labels=parseClipboardAssignments(newAssignment);
      if(!labels.length){setQuickError('Enter or paste at least one task.');return;}
      if(labels.length>100){setQuickError('Maximum 100 tasks per paste.');return;}
      const invalid=labels.findIndex(label=>label.length>160);
      if(invalid!==-1){setQuickError(`Task ${invalid+1} exceeds 160 characters. Please shorten it.`);return;}
      setQuickAdding(true);setQuickError('');
      try{
       const context={memberId:selected.id,startWeek:selected.week};
       await onQuickTaskCreate(labels.length===1?{...context,label:labels[0]}:{...context,labels});
       setQuickNotice(labels.length===1?'1 task added.':`${labels.length} tasks added from your list.`);
       setNewAssignment('');setAddingAssignment(false);
      }catch(error:any){setQuickError(error?.message||'Could not save assignments. No tasks were added.');}
      finally{setQuickAdding(false);}
     }}>
       <label htmlFor="nb-quick-new-task">New assignment for {selectedPerson?.name}</label>
       <textarea id="nb-quick-new-task" required maxLength={20000} autoFocus rows={newAssignmentList.length>1?5:2} placeholder="Type a task or paste a • bulleted list from Excel…" value={newAssignment} disabled={quickAdding} onChange={e=>{setNewAssignment(e.target.value);setQuickError('');}} onKeyDown={e=>{
        if(e.key==='Escape'){e.stopPropagation();setAddingAssignment(false);setNewAssignment('');setQuickError('');return;}
        if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();e.currentTarget.form?.requestSubmit();return;}
        if(e.key==='Enter'&&!e.shiftKey&&!e.ctrlKey&&!e.metaKey&&!newAssignment.includes('\n')&&newAssignmentList.length===1){e.preventDefault();e.currentTarget.form?.requestSubmit();}
       }}/>
       {newAssignmentList.length>1&&<div className="nb89-bulk-preview" aria-live="polite">
        <strong>{newAssignmentList.length} separate tasks detected</strong>
        <ol>{newAssignmentList.slice(0,8).map((label:string,index:number)=><li key={index}>{label}</li>)}</ol>
        {newAssignmentList.length>8&&<small>+ {newAssignmentList.length-8} more tasks</small>}
       </div>}
       {newAssignmentList.length>100&&<p className="nb-quick-error" role="alert">Maximum 100 tasks per paste.</p>}
       {invalidTaskIndex>=0&&<p className="nb-quick-error" role="alert">Task {invalidTaskIndex+1} exceeds 160 characters. Shorten this task to continue.</p>}
       <p className="nb89-paste-hint">Paste an Excel cell with • bullets, or one task per line. Enter adds a single task; Ctrl+Enter saves a list.</p>
       <div className="nb-quick-add-buttons"><button type="submit" className="nb-button nb-primary" disabled={quickAdding||!canAddAssignments}>{quickAdding?'Saving…':newAssignmentList.length>1?`Add ${newAssignmentList.length} tasks`:'Add task'}</button><B disabled={quickAdding} onClick={()=>{setAddingAssignment(false);setNewAssignment('');setQuickError('');}}>Cancel</B></div>
      </form>}
     {quickError&&<p className="nb-quick-error" role="alert">{quickError}</p>}
    </div>:selected.id===UNASSIGNED_MEMBER_ID?<p className="nb-quick-view-note">Unassigned tasks are preserved. Sign in as Admin to reassign them.</p>:<div className="nb-drawer-view-footer"><span>Sign in as Admin to update tasks.</span><button type="button" className="nb-button nb-drawer-edit-button" onClick={()=>{closeQuickPanel();onAuth();}}><ShieldCheck size={17} aria-hidden="true"/> Sign in</button></div>}
    </aside>
   </>,document.body)}

  {memberPendingDeletion&&isAdmin&&createPortal(
   <div className="nb-member-delete-scrim" onMouseDown={e=>{if(e.target===e.currentTarget&&!memberBusy)setMemberToDelete(null);}}>
    <section ref={memberDialogRef} className="nb-member-delete-dialog" role="alertdialog" aria-modal="true" aria-labelledby="nb-member-delete-title" aria-describedby="nb-member-delete-description">
     <div className="nb-member-delete-symbol" aria-hidden="true"><AlertCircle size={23}/></div>
     <h2 id="nb-member-delete-title">Permanently delete {memberPendingDeletion.name}?</h2>
     <p id="nb-member-delete-description"><strong>Warning: this action cannot be undone.</strong> Deleting this employee will permanently remove their task history from this project.</p>
     <ul className="nb-member-delete-impact">
      <li><strong>{pendingOwnedTasks.length}</strong> owned task(s) and their history will be deleted.</li>
      <li><strong>{pendingHelperTasks.length}</strong> helper assignment(s) on other tasks will be removed; those tasks will remain.</li>
      <li><strong>{pendingOwnedSystems.length}</strong> system ownership link(s) will be cleared; the systems will remain.</li>
     </ul>
     <p className="nb-member-delete-backup">Export a backup before continuing if you may need the deleted task history.</p>
     {memberError&&<p className="nb-member-delete-error" role="alert">{memberError}</p>}
     <div className="nb-member-delete-buttons">
      <button type="button" autoFocus className="nb-button nb-member-delete-cancel" disabled={memberBusy} onClick={()=>{setMemberToDelete(null);setMemberError('');}}>Cancel — keep employee</button>
      <button type="button" className="nb-button nb-member-delete-confirm" disabled={memberBusy} onClick={()=>{void confirmMemberDelete();}}>{memberBusy?'Deleting…':'Yes, permanently delete'}</button>
     </div>
    </section>
   </div>,document.body)}

  <footer className="nb-week-footer nb-aligned-week-footer nb-approved-week-footer" aria-label="Project weeks navigation">
   <div className="nb-week-card-scroller" ref={weekFooterScrollRef}>
    <div className="nb-week-card-grid" ref={weekFooterGridRef}>
     <div className="nb-week-navigation-label nb-week-navigation-home">
      <strong>Project weeks</strong>
      <B className="nb-go-today nb-today-action" onMouseDown={(event:React.MouseEvent)=>event.preventDefault()} onClick={()=>{
       if(currentWeek>=0&&currentWeek<520){resetWeekScroll();selectWeek(currentWeek);setWeek(clampWeekViewport(currentWeek));}
      }} aria-label="Jump to current project week" disabled={currentWeek<0||currentWeek>=520}>
       <CalendarDays size={17} aria-hidden="true"/> Today
      </B>
     </div>
     {weeks.map((w,index)=>{
      const days=projectWeekDays(project.startDate,w);
      const isCurrent=currentWeek===w;
      return <div key={w} className={'nb-week-nav-shell '+(index===0?'nb-week-nav-first ':'')+(index===3?'nb-week-nav-last ':'')}>
       <button type="button" className={'nb-week-wide-card '+(w===selectedWeek?'nb-week-wide-selected ':'')+(isCurrent?'nb-week-wide-current ':'')}
        aria-pressed={w===selectedWeek} aria-current={isCurrent?'date':undefined}
        aria-label={`${weekIso(w)}, ${weekRange(project.startDate,w)}${isCurrent?', current week':''}`}
        onClick={()=>selectWeek(w)}>
        <strong>{weekIso(w)}</strong>
        <span className="nb-week-wide-date">{weekRange(project.startDate,w)}</span>
        <span className="nb-week-wide-days" aria-label="Seven days of this project week">
         {days.map((day:any)=><span key={day.date} className={'nb-week-day '+(day.date===todayDate?'nb-week-day-today':'')}
          aria-current={day.date===todayDate?'date':undefined} title={`${day.weekday}, ${day.date}`}>
          {day.short}
         </span>)}
        </span>
       </button>
       {index===0&&<B disabled={week<=0} onMouseDown={(event:React.MouseEvent)=>event.preventDefault()}
        onClick={()=>navigateWeek(-1)} aria-label="Previous project week" className="nb-week-arrow nb-weeks-prev"><ChevronLeft size={21} aria-hidden="true"/></B>}
       {index===3&&<B disabled={week>=516} onMouseDown={(event:React.MouseEvent)=>event.preventDefault()}
        onClick={()=>navigateWeek(1)} aria-label="Next project week" className="nb-week-arrow nb-weeks-next"><ChevronRight size={21} aria-hidden="true"/></B>}
      </div>;
     })}
    </div>
   </div>
  </footer>
  {milestoneEditor&&createPortal(<div className="nb42-dialog-backdrop" onMouseDown={event=>{if(event.target===event.currentTarget&&!milestoneBusy)setMilestoneEditor(null);}}>
   <section role="dialog" aria-modal="true" aria-labelledby="nb42-milestone-title" className="nb42-milestone-dialog">
    <div className="nb42-dialog-header"><div><span className="nb42-dialog-eyebrow">{weekIso(milestoneEditor.startWeek)} · Project milestone</span><h2 id="nb42-milestone-title">{milestoneEditor.creating?'Add milestone':'Edit milestone'}</h2></div>
     <button type="button" className="nb42-dialog-close" aria-label="Close milestone editor" disabled={milestoneBusy} onClick={()=>setMilestoneEditor(null)}><X size={19}/></button>
    </div>
    <form onSubmit={saveMilestone}>
     <label className="nb42-milestone-name-label" htmlFor="nb42-milestone-name">Milestone name</label>
     <input autoFocus id="nb42-milestone-name" required maxLength={160} value={milestoneDraft} disabled={milestoneBusy} placeholder="Enter milestone title" onChange={event=>{setMilestoneDraft(event.target.value);setMilestoneError('');}}/>
     {milestoneError&&<p role="alert" className="nb42-milestone-error">{milestoneError}</p>}
     <div className="nb42-dialog-actions">
      {!milestoneEditor.creating&&<button type="button" className="nb42-delete-action" disabled={milestoneBusy} onClick={deleteMilestone}><Trash2 size={15}/> Delete</button>}
      <button type="button" className="nb42-dialog-cancel" disabled={milestoneBusy} onClick={()=>setMilestoneEditor(null)}>Cancel</button>
      <button type="submit" className="nb42-dialog-save" disabled={milestoneBusy||!milestoneDraft.trim()}><Check size={16}/>{milestoneBusy?'Saving…':'Save milestone'}</button>
     </div>
    </form>
   </section>
  </div>,document.body)}
 </section>;
}

export function Report({project,isAdmin,onSystemChange,onSystemCreate,onSystemDelete,onRequestAdmin,onDisableAdmin}:any){
 const [query,setQuery]=useState(''),[scope,setScope]=useState('All'),[owner,setOwner]=useState(''),[cyber,setCyber]=useState(''),[venue,setVenue]=useState('');
 // Every report column remains visible; sorting is available in its column header.
 const hidden:string[]=[];
 const [sort,setSort]=useState('reference'),[sortDirection,setSortDirection]=useState<'asc'|'desc'>('asc');
 const [editor,setEditor]=useState<any>(null),[saving,setSaving]=useState(false),[saveMessage,setSaveMessage]=useState(''),[formError,setFormError]=useState('');
 const [confirmDeleteId,setConfirmDeleteId]=useState<string|null>(null);
 const [recentlyCreatedId,setRecentlyCreatedId]=useState<string|null>(null);
 const newRowRef=useRef<HTMLTableRowElement|null>(null);
 const reportSummary=reportCounts(project,counts);
 const allColumns=['System','Qty','Venue','Base','Ready','Deployed','AW','Cyber','Owner'];
 const memberName=(sys:any)=>sys.assignmentOwnerLabel||sys.reportOwnerName||project.members.find((m:any)=>m.id===sys.assigneeId)?.name||'Unassigned';
 const displayVenue=(sys:any)=>sys.reportVenue||[...new Set((sys.devices||[]).map((d:any)=>d.venue).filter(Boolean))].join(', ')||'—';
 const displayAw=(sys:any)=>{const v=sys.reportAW??sys.airWatchTags??sys.airWatch??sys.mdm;if(v===true)return 'Yes';if(v===false)return 'No';const s=String(v||'').trim();return ['Yes','No','Pending','N/A'].includes(s)?s:s?'Specified':'—';};
 const compare=(a:any,b:any)=>{const key=(sys:any)=>sort==='reference'?(sys.reportOrder??100000):sort==='name'?sys.name:sort==='qty'?counts(sys).total:sort==='venue'?displayVenue(sys):sort==='base'?counts(sys).base:sort==='ready'?counts(sys).ready:sort==='deployed'?counts(sys).deployed:sort==='aw'?displayAw(sys):sort==='cyber'?normalizeCyberStatus(sys.cyberStatus):memberName(sys);const x=key(a),y=key(b);const n=typeof x==='number'&&typeof y==='number'?x-y:String(x).localeCompare(String(y));return sortDirection==='asc'?n:-n;};
 const changeSort=(key:string)=>{if(sort===key)setSortDirection(v=>v==='asc'?'desc':'asc');else{setSort(key);setSortDirection('asc');}};
 const normalizedQuery=query.trim().toLowerCase();
 const systems=[...project.systems].filter((s:any)=>{
  const total=counts(s);
  if(normalizedQuery&&![s.name,s.deviceType,s.os,displayVenue(s),memberName(s),...(s.devices||[]).flatMap((d:any)=>[d.identity,d.venue])].some(v=>String(v||'').toLowerCase().includes(normalizedQuery)))return false;
  if(venue&&displayVenue(s)!==venue)return false;
  if(owner&&memberName(s)!==owner)return false;
  if(cyber&&normalizeCyberStatus(s.cyberStatus)!==cyber)return false;
  return scope==='All'||(scope==='Not started'?total.base===0:total.base>0&&total.deployed<total.total);
 }).sort(compare);
 const rows=systems;
 // Keep current filters and sort untouched. Once the created row is actually
 // rendered, scroll it into view and pulse exactly three times, then clear it.
 const newlyCreatedIsVisible=!!recentlyCreatedId&&rows.some((s:any)=>s.id===recentlyCreatedId);
 useEffect(()=>{
  if(!recentlyCreatedId||!newlyCreatedIsVisible)return;
  const frame=requestAnimationFrame(()=>newRowRef.current?.scrollIntoView({block:'nearest',inline:'nearest',behavior:'smooth'}));
  const timer=window.setTimeout(()=>setRecentlyCreatedId(id=>id===recentlyCreatedId?null:id),3100);
  return ()=>{cancelAnimationFrame(frame);clearTimeout(timer);};
 },[recentlyCreatedId,newlyCreatedIsVisible]);
 const isCreating=!!editor&&!project.systems.some((s:any)=>s.id===editor.id);
 const visibleCount=allColumns.filter(c=>!hidden.includes(c)).length+1;
 const allVenues=[...new Set(project.systems.map((s:any)=>displayVenue(s)).filter((s:string)=>s!=='—'))].sort();
 const allOwners=[...new Set(project.systems.map(memberName))].sort();
 const kpis=[
  ['Base Configuration','base',reportSummary.base,reportSummary.total,Settings2],
  ['Ready for Deployment','ready',reportSummary.ready,reportSummary.total,Rocket],
  ['Deployed','deployed',reportSummary.deployed,reportSummary.total,Layers3],
  ['Cyber Approved','cyber',reportSummary.cyberApproved,reportSummary.cyberApplicable,ShieldCheck],
 ] as any[];
 const progress=(n:number,t:number)=> t>0?<span className="nb-report-progress"><span className="nb-progress-label"><small>{n.toLocaleString('en-US')}</small><strong>{Math.round(n/t*100)}%{n===t?' ✓':''}</strong></span><progress max={t} value={n} aria-label={`${n} out of ${t} completed`}/></span>:<span className="nb-muted">—<small>No device inventory</small></span>;
 const openEditor=(sys?:any)=>{if(!isAdmin){onRequestAdmin?.();return;}setFormError('');setSaveMessage('');setConfirmDeleteId(null);setEditor(sys?{...sys,reportMetrics:{...counts(sys)},reportVenue:displayVenue(sys)==='—'?'':displayVenue(sys),reportAW:displayAw(sys)==='—'?'':displayAw(sys),reportOwnerName:memberName(sys)==='Unassigned'?'':memberName(sys)}:{id:uid(),name:'',deviceType:'',deviceCategory:'PC',os:'Other',osVersion:'',network:'',vlan:'',serviceAccount:'',userAccount:'',logonType:'',ipScope:'',ipReservation:'',domainOU:'',airWatchTags:'',status:'Active',devices:[],deviceRuns:[],reportMode:'aggregate-sample',reportMetrics:{total:0,base:0,ready:0,deployed:0},reportVenue:'',reportAW:'Pending',reportOwnerName:'',cyberStatus:'Not Started'});};
 const saveEditor=async(e?:any)=>{e?.preventDefault?.();if(!editor||saving)return;setFormError('');
  try{
   if(!editor.name?.trim())throw Error('System name is required.');
   if(['total','base','ready','deployed'].some(key=>editor.reportMetrics?.[key]===''))throw Error('Enter quantity and completed counts for all stages.');
   if(project.systems.some((s:any)=>s.id!==editor.id&&s.name.trim().toLowerCase()===editor.name.trim().toLowerCase()))throw Error('This system name already exists.');
   const metrics=validateAggregateMetrics(editor.reportMetrics);
   const original=project.systems.find((s:any)=>s.id===editor.id);
   if(original?.devices?.length&&original.reportMode!=='aggregate-sample'){
    const actual=counts(original);if(['total','base','ready','deployed'].some(key=>metrics[key]!==actual[key]))throw Error('Registered device progress must be edited through its device checklists.');
   }
   const cyberChanged=normalizeCyberStatus(editor.cyberStatus)!==normalizeCyberStatus(original?.cyberStatus);
   const next={...editor,name:editor.name.trim(),deviceType:editor.deviceType.trim(),reportVenue:editor.reportVenue.trim().toUpperCase(),reportOwnerName:editor.reportOwnerName.trim(),reportAW:editor.reportAW,airWatchTags:editor.reportAW,cyberStatus:normalizeCyberStatus(editor.cyberStatus),reportMetrics:metrics,reportMode:original?.devices?.length&&original.reportMode!=='aggregate-sample'?original.reportMode:'aggregate-sample',cyberHistory:cyberChanged?[...(original?.cyberHistory||[]),{status:normalizeCyberStatus(editor.cyberStatus),actor:'local-demo',at:new Date().toISOString()}]:original?.cyberHistory||[]};
   setSaving(true);
   if(original)await onSystemChange(next);else await onSystemCreate(next);
   if(!original)setRecentlyCreatedId(next.id);
   setEditor(null);setConfirmDeleteId(null);setSaveMessage(`System “${next.name}” saved.`);
  }catch(error:any){setFormError(error?.message||'Unable to save system.');}finally{setSaving(false);}
 };
 const deleteEditor=async(sys:any)=>{if(!isAdmin||saving||confirmDeleteId!==sys.id)return;
  try{setSaving(true);setFormError('');await onSystemDelete(sys.id);setConfirmDeleteId(null);setEditor(null);setSaveMessage(`System “${sys.name}” deleted.`);}catch(error:any){setFormError(error?.message||'Unable to delete system.');}finally{setSaving(false);}
 };
 const cancelEditor=()=>{setEditor(null);setFormError('');};
 const editableRegistered=(sys:any)=>!!(sys?.devices?.length&&sys.reportMode!=='aggregate-sample');
 const inlineNumber=(key:'total'|'base'|'ready'|'deployed',label:string)=>{
  const isLocked=!!editor&&editableRegistered(project.systems.find((s:any)=>s.id===editor.id));
  const value=editor?.reportMetrics?.[key]??0;
  return <input className="nb-report-inline-number" type="number" step="1" min="0" max={key==='total'?1000000:(editor?.reportMetrics?.total||0)} aria-label={label} value={value} disabled={saving||isLocked} title={isLocked?'Registered device progress is edited in its device checklist':label} onChange={e=>changeMetric(key,e.target.value)}/>;
 };
 const inlineProgress=(key:'base'|'ready'|'deployed',label:string)=>{
  const n=Number(editor?.reportMetrics?.[key]||0),total=Number(editor?.reportMetrics?.total||0);
  return <div className="nb-report-inline-progress">{inlineNumber(key,label)}<span className="nb-report-inline-percent">{total>0&&n>=0?`${Math.round(n/total*100)}%`:'—'}</span><progress value={Math.max(0,Math.min(total,n))} max={Math.max(1,total)} aria-label={label+' progress'}/></div>;
 };
 const inlineActions=<div className="nb-report-inline-actions"><button type="button" className="nb-report-inline-save" disabled={saving} onClick={()=>saveEditor()} aria-label="Save system"><Check size={15}/> Save</button><button type="button" disabled={saving} onClick={cancelEditor} aria-label="Cancel editing"><X size={14}/> Cancel</button></div>;
 const inlineRow=editor&&<tr key={'editing-'+editor.id} className="nb-report-editing-row" onKeyDown={e=>{if(e.key==='Escape')cancelEditor();if(e.key==='Enter'&&(e.target as HTMLElement).tagName==='INPUT'&&!saving){e.preventDefault();saveEditor();}}}>
   <td><div className="nb-report-name-editor"><input required autoFocus aria-label="System name" maxLength={140} placeholder="System name" value={editor.name} onChange={e=>changeField('name',e.target.value)}/><input aria-label="Device model" maxLength={180} placeholder="Device model" value={editor.deviceType||''} onChange={e=>changeField('deviceType',e.target.value)}/>{formError&&<span className="nb-report-row-error" role="alert">{formError}</span>}</div></td>
   <td hidden={hidden.includes('Qty')}>{inlineNumber('total','Quantity')}</td>
   <td hidden={hidden.includes('Venue')}><input aria-label="Venue" maxLength={30} value={editor.reportVenue||''} onChange={e=>changeField('reportVenue',e.target.value)}/></td>
   <td className="nb-stage-base" hidden={hidden.includes('Base')}>{inlineProgress('base','Base configuration completed')}</td>
   <td className="nb-stage-ready" hidden={hidden.includes('Ready')}>{inlineProgress('ready','Ready for deployment completed')}</td>
   <td className="nb-stage-deployed" hidden={hidden.includes('Deployed')}>{inlineProgress('deployed','Deployed devices')}</td>
   <td hidden={hidden.includes('AW')}><select aria-label="AW" value={editor.reportAW||''} onChange={e=>changeField('reportAW',e.target.value)}>{['Yes','No','Pending','N/A',''].map(v=><option key={v} value={v}>{v||'—'}</option>)}</select></td>
   <td hidden={hidden.includes('Cyber')}><select aria-label="Cyber status" value={normalizeCyberStatus(editor.cyberStatus)} onChange={e=>changeField('cyberStatus',e.target.value)}>{CYBER_STATUSES.map(v=><option key={v} value={v}>{v}</option>)}</select></td>
   <td hidden={hidden.includes('Owner')}>{editor.assignmentOwnerLabel?<span title="Change this owner in Assignment">{editor.assignmentOwnerLabel}</span>:<input aria-label="Owner" maxLength={100} value={editor.reportOwnerName||''} onChange={e=>changeField('reportOwnerName',e.target.value)}/>}</td>
   <td className="nb-report-action-cell">{inlineActions}</td>
  </tr>;
 const changeField=(key:string,v:any)=>setEditor((old:any)=>({...old,[key]:v}));
 const changeMetric=(key:string,v:string)=>setEditor((old:any)=>({...old,reportMetrics:{...old.reportMetrics,[key]:v}}));
 return <section className="nb-report nb-report-reference-v032">
  <header className="nb-page-header nb45-primary-header"><div><h1>Configuration Report</h1><p>Legend of the Seas · Deployment overview</p></div><div className="nb-actions"/></header>
  <div className="nb-kpis">{kpis.map(([label,key,n,t,Icon]:any)=><article className="nb-kpi" key={key}><div><span className={'nb-kpi-icon nb-kpi-icon-'+key}><Icon size={24} strokeWidth={2}/></span><h3>{label}</h3><strong>{t?Math.round(n/t*100)+'%':'—'}</strong><div className={'nb-kpi-ring nb-kpi-ring-'+key} role="img" aria-label={`${label}: ${n} of ${t}`} style={{background:`conic-gradient(var(--report-kpi-accent) ${t?n/t*100:0}%, #e4edf8 0)`}}><span/></div><p>{t?`${n.toLocaleString('en-US')} / ${t.toLocaleString('en-US')} ${key==='cyber'?'applicable systems':'devices'}`:key==='deployed'?'No deployment records':'No registered device data'}</p></div></article>)}</div>
  <section className="nb-report-readiness-panel" aria-label="System readiness">
   <div className="nb-readiness-heading"><h2>System readiness <small>{systems.length} systems</small></h2><div className="nb-scope-tabs" role="group" aria-label="Readiness scope">{['All','In progress','Not started'].map(v=><B key={v} aria-pressed={scope===v} onClick={()=>setScope(v)}>{v}</B>)}</div><div className="nb-report-manage-actions">{isAdmin&&<B onClick={()=>openEditor()} className="nb-report-add-system"><Plus size={16}/> Add system</B>}</div></div>
   <div className="nb-toolbar nb-report-filters">
    <label className="nb-report-search"><Search size={19} aria-hidden="true"/><input aria-label="Search systems" placeholder="Search systems or devices..." value={query} onChange={e=>setQuery(e.target.value)}/></label>
    <select aria-label="Venue scope" value={venue} onChange={e=>setVenue(e.target.value)}><option value="">All venues</option>{allVenues.map(v=><option key={v} value={v}>{v}</option>)}</select>
    <select aria-label="Owner scope" value={owner} onChange={e=>setOwner(e.target.value)}><option value="">All assignees</option>{allOwners.map(v=><option key={v} value={v}>{v}</option>)}</select>
    <select aria-label="Cyber scope" value={cyber} onChange={e=>setCyber(e.target.value)}><option value="">All cyber statuses</option>{CYBER_STATUSES.map(v=><option key={v}>{v}</option>)}</select>

   </div>
   <div className="nb-report-table nb-report-continuous"><table><thead><tr>{allColumns.map(v=>{const key=({System:'name',Qty:'qty',Venue:'venue',Base:'base',Ready:'ready',Deployed:'deployed',AW:'aw',Cyber:'cyber',Owner:'owner'} as any)[v];return <th key={v} hidden={hidden.includes(v)} aria-sort={sort===key?(sortDirection==='asc'?'ascending':'descending'):'none'}><button className="nb-report-th-sort" onClick={()=>changeSort(key)}>{({Base:'Base config.',Ready:'Ready to deploy'} as any)[v]||v}<span aria-hidden="true">{sort===key?(sortDirection==='asc'?'⌃':'⌄'):'↕'}</span></button></th>})}<th className="nb-report-actions-th">Actions</th></tr></thead>
    <tbody>
     {isCreating&&inlineRow}
     {rows.map((s:any)=>{const c=counts(s);if(editor?.id===s.id)return inlineRow;return <tr key={s.id} ref={s.id===recentlyCreatedId?newRowRef:undefined} className={"nb-report-data-row"+(s.id===recentlyCreatedId?" nb59-new-system-highlight":"")}><td><strong className="nb-report-system-name">{s.name}</strong><small>{s.deviceType||s.deviceCategory||'Device profile'}</small></td><td hidden={hidden.includes('Qty')}>{c.total||'—'}</td><td hidden={hidden.includes('Venue')}>{displayVenue(s)}</td><td className="nb-stage-base" hidden={hidden.includes('Base')}>{progress(c.base,c.total)}</td><td className="nb-stage-ready" hidden={hidden.includes('Ready')}>{progress(c.ready,c.total)}</td><td className="nb-stage-deployed" hidden={hidden.includes('Deployed')}>{progress(c.deployed,c.total)}</td><td hidden={hidden.includes('AW')}>{displayAw(s)}</td><td hidden={hidden.includes('Cyber')}><Badge value={normalizeCyberStatus(s.cyberStatus)}/></td><td hidden={hidden.includes('Owner')}>{memberName(s)}</td><td className="nb-report-action-cell">{confirmDeleteId===s.id?<div className="nb-report-delete-confirm"><span>Delete this system and its history?</span><button disabled={saving} onClick={()=>deleteEditor(s)} className="nb-report-confirm-danger" aria-label={'Confirm delete '+s.name}>Delete</button><button onClick={()=>setConfirmDeleteId(null)}>Cancel</button></div>:<div className="nb-report-row-actions">{isAdmin&&<button type="button" aria-label={'Edit '+s.name} title="Edit system inline" onClick={()=>openEditor(s)}><Pencil size={15}/></button>}{isAdmin&&<button type="button" aria-label={'Delete '+s.name} title="Delete system" onClick={()=>{setEditor(null);setConfirmDeleteId(s.id);}}><Trash2 size={15}/></button>}</div>}</td></tr>})}
     {rows.length===0&&!isCreating&&<tr><td colSpan={visibleCount} className="nb-report-no-results">No systems match the current filters.</td></tr>}
    </tbody></table></div>
   <div className="nb-report-continuous-footer"><span>Showing all {systems.length} systems · Scroll to view the full list</span></div>
   {formError&&!editor&&<p role="alert" className="nb-report-form-error nb-report-inline-error">{formError}</p>}
   {saveMessage&&<p role="status" className="nb-report-save-message">{saveMessage}</p>}
  </section>
 </section>;
}


export function Overview({project,onNavigate}:any){
 const [historyOpen,setHistoryOpen]=useState(false);
 const reportSummary=reportCounts(project,counts);
 const timezone=project.timezone||'Europe/Paris';
 const activeWeek=Math.max(0,currentWeekIndex(project.startDate,timezone)??0);
 const tasks=(project.tasks||[]).filter((t:any)=>!t.isMilestone).map((t:any)=>({...t,status:effectiveStatus(t,project.issues||[])}));
 const milestones=(project.tasks||[]).filter((t:any)=>t.isMilestone);
 const openIssues=(project.issues||[]).filter((issue:any)=>!['Resolved','Closed'].includes(issue.status));
 const currentWeekTasks=tasks.filter((task:any)=>task.startWeek<=activeWeek&&task.startWeek+(task.duration||1)>activeWeek);
 const currentWeekMilestones=milestones.filter((task:any)=>task.startWeek===activeWeek||task.startWeek===activeWeek+1);
 const weekStats={
  planned:currentWeekTasks.filter((task:any)=>task.status==='Planned').length,
  active:currentWeekTasks.filter((task:any)=>task.status==='In Progress').length,
  blocked:currentWeekTasks.filter((task:any)=>task.status==='Blocked').length,
  done:currentWeekTasks.filter((task:any)=>task.status==='Completed').length,
 };
 const memberName=(id:string)=>project.members?.find((m:any)=>m.id===id)?.name||'';
 const ownerName=(sys:any)=>sys.assignmentOwnerLabel||memberName(sys.assigneeId)||sys.reportOwnerName||'Not matched';
 const venueName=(sys:any)=>sys.reportVenue||sys.venue||'—';
 // Issues and unfinished rollout are two different operational signals.
 const issueRows=openIssues.map((issue:any)=>({
  issue,system:(project.systems||[]).find((sys:any)=>sys.id===issue.systemId),
  severity:String(issue.severity||'').toLowerCase()
 })).sort((a:any,b:any)=>({critical:0,high:1,medium:2,low:3}[a.severity]??4)-({critical:0,high:1,medium:2,low:3}[b.severity]??4)).slice(0,3);
 // Stage-aware attention: the displayed percentage, progress bar and pending
 // message must ALL come from the same actionable rollout stage.
 const allSetupRows=getAttentionRows(project.systems||[],counts);
 const setupRows=allSetupRows.slice(0,3);
 const readinessRows=[...(project.systems||[])].sort((a:any,b:any)=>{const ca=counts(a),cb=counts(b);return (cb.total-ca.total)||String(a.name).localeCompare(String(b.name));}).slice(0,5);
 const activityItems=Array.isArray(project.activityLog)?project.activityLog:[];
 const ownership=(project.systems||[]).reduce((acc:any,sys:any)=>{
  const label=ownerName(sys);
  if(!label||label==='Not matched'||label==='Unassigned')acc.unmatched+=1;
  else acc.assigned+=1;
  return acc;
 },{assigned:0,multiple:0,unmatched:0});
 const totalSystems=Math.max(1,(project.systems||[]).length);
 const formatDate=(value:string)=>{
  if(!value)return '—';
  try{return new Date(value+'T12:00:00Z').toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'});}catch{return value;}
 };
 const formatDateTime=(value:string)=>{
  if(!value)return 'No timestamp';
  const date=new Date(value);
  if(Number.isNaN(date.getTime()))return value;
  return date.toLocaleDateString('en-GB',{day:'numeric',month:'short'})+', '+date.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
 };
 const kpis=[
  {label:'Base Configuration',value:reportSummary.total?Math.round(reportSummary.base/reportSummary.total*100):0,count:`${reportSummary.base.toLocaleString('en-US')} / ${reportSummary.total.toLocaleString('en-US')} devices`,tab:'config-report',accent:'base',Icon:Settings2,colors:{primary:'#2377f3',light:'#78c7ff',dark:'#0b58d7',track:'#dcecff',shades:['#f7fbff','#dff1ff','#bcdfff','#84c7ff','#2377f3']}},
  {label:'Ready for Deployment',value:reportSummary.total?Math.round(reportSummary.ready/reportSummary.total*100):0,count:`${reportSummary.ready.toLocaleString('en-US')} / ${reportSummary.total.toLocaleString('en-US')} devices`,tab:'config-report',accent:'ready',Icon:Rocket,colors:{primary:'#8065ed',light:'#c8b4ff',dark:'#5743d5',track:'#eee9ff',shades:['#fbf9ff','#efe5ff','#dac9ff','#b292ff','#8065ed']}},
  {label:'Deployed',value:reportSummary.total?Math.round(reportSummary.deployed/reportSummary.total*100):0,count:`${reportSummary.deployed.toLocaleString('en-US')} / ${reportSummary.total.toLocaleString('en-US')} devices`,tab:'config-report',accent:'deployed',Icon:Layers3,colors:{primary:'#10b2cc',light:'#7fe7ed',dark:'#068ca7',track:'#d9f6fa',shades:['#f2feff','#d8fbff','#b2f3fa','#76e1eb','#10b2cc']}},
  {label:'Cyber Approved',value:reportSummary.cyberApplicable?Math.round(reportSummary.cyberApproved/reportSummary.cyberApplicable*100):0,count:`${reportSummary.cyberApproved.toLocaleString('en-US')} / ${reportSummary.cyberApplicable.toLocaleString('en-US')} applicable systems`,tab:'config-report',accent:'cyber',Icon:ShieldCheck,colors:{primary:'#12ab87',light:'#75eac4',dark:'#07886b',track:'#dcf8ee',shades:['#f2fffb','#dbfff1','#baf7e0','#7be6bc','#12ab87']}},
 ];
 const miniProgress=(value:number,total:number,variant:string)=> <div className="nb-overview-progress"><span>{total>0?`${Math.round(value/total*100)}%`:'—'}</span><div className="nb-overview-progress-track"><i className={`nb-overview-progress-fill nb-overview-progress-fill--${variant}`} style={{width:`${total>0?Math.max(4,Math.min(100,Math.round(value/total*100))):0}%`}}/></div></div>;
 return <section className="nb-overview nb-overview-premium">
  <header className="nb-page-header nb-overview-header">
   <div>
    <h1>Overview</h1>
    <p>{project.name} · Project status at a glance</p>
   </div>
   <div className="nb-overview-header-meta">
    <div className="nb-overview-meta-card nb63-project-start">
     <span className="nb63-meta-icon" aria-hidden="true"><Flag size={18}/></span>
     <div className="nb63-meta-copy"><span>Project start</span><strong>{formatDate(project.startDate)}</strong></div>
    </div>
    <button type="button" className="nb-overview-meta-card nb-overview-meta-card--primary nb63-current-week" onClick={()=>onNavigate('roadmap')}>
     <span className="nb63-meta-icon" aria-hidden="true"><CalendarDays size={18}/></span>
     <div className="nb63-meta-copy"><span>Current week</span><strong>{`Week ${activeWeek+1}`}</strong><small>{weekRange(project.startDate,activeWeek)}</small></div>
     <ChevronRight size={16} aria-hidden="true" className="nb63-week-chevron"/>
    </button>
   </div>
  </header>

  <div className="nb-overview-kpi-grid">
   {kpis.map((item:any)=>{
    const percent=Math.max(0,Math.min(100,Number(item.value)||0));
    const circumference=2*Math.PI*48;
    const innerCircumference=2*Math.PI*41.5;
    const ringId=`nb64-ring-${item.accent}`;
    const waterline=100-percent*.8;
    const bubbleDepth=Math.max(7,100-waterline);
    const bubbles=[
     {x:31,depth:.84,r:2.6},{x:44,depth:.51,r:1.7},
     {x:55,depth:.91,r:2.4},{x:67,depth:.65,r:1.6},
     {x:77,depth:.81,r:2.3},{x:88,depth:.56,r:1.9},
     {x:60,depth:.35,r:1.5},{x:39,depth:.72,r:1.8},
     {x:73,depth:.42,r:1.9}
    ];
    return <button type="button" key={item.label} className={`nb-overview-kpi-card nb-overview-kpi-card--${item.accent} nb64-kpi-card`} onClick={()=>onNavigate(item.tab)}>
     <div className="nb-overview-kpi-card__gloss" aria-hidden="true"/>
     <div className="nb-overview-kpi-card__reflection" aria-hidden="true"/>
     <div className="nb-overview-kpi-card__content">
      <div className="nb-overview-kpi-copy nb64-kpi-copy">
       <h3>{item.label}</h3>
       <div className="nb64-kpi-reading">
        <span className="nb64-kpi-symbol" aria-hidden="true" style={{width:50,height:50,flex:'0 0 50px',display:'grid',placeItems:'center',color:item.colors.primary,background:`linear-gradient(145deg,#ffffff,${item.colors.track})`,border:`1px solid ${item.colors.track}`,borderRadius:14,boxShadow:'0 3px 11px rgba(23,60,110,.10)'}}><item.Icon size={37} color={item.colors.primary} strokeWidth={1.9}/></span>
        <div className="nb64-kpi-figures"><strong>{percent}%</strong><p>{item.count}</p></div>
       </div>
      </div>
      <span className={`nb64-liquid-ring nb64-liquid-ring--${item.accent} nb66-liquid-ring nb70-liquid-ring nb70-liquid-ring--${item.accent} ${percent===0?'nb66-liquid-ring--empty':''}`} role="img" aria-label={`${item.label}: ${percent}% complete`} style={{'--nb66-primary':item.colors.primary,'--nb66-light':item.colors.light,'--nb66-track':item.colors.track,'--nb66-fill':`${percent}%`} as React.CSSProperties}>
       <span className="nb66-liquid-chamber" aria-hidden="true">
        <span className="nb66-liquid-fill">
         <span className="nb66-liquid-surface nb66-liquid-surface--back"/>
         <span className="nb68-liquid-refraction"/>
         <span className="nb66-liquid-surface nb66-liquid-surface--front"/>
         <span className="nb68-liquid-undertow"/>
         <span className="nb66-bubble nb66-bubble--one"/>
         <span className="nb66-bubble nb66-bubble--two"/>
         <span className="nb66-bubble nb66-bubble--three"/>
        </span>
        <span className="nb66-liquid-gloss"/>
        <span className="nb68-glass-reflection"/>
        <span className="nb68-glass-rim"/>
       </span>
       <svg className="nb66-liquid-svg" viewBox="0 0 120 120" width="100%" height="100%" aria-hidden="true" focusable="false">
        <defs>
         <linearGradient id={ringId} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={item.colors.light}/>
          <stop offset="45%" stopColor={item.colors.primary}/>
          <stop offset="100%" stopColor={item.colors.dark}/>
         </linearGradient>
         {/* The underlying water gradient spans only the actual filled part
             of the circle, so even 12% visibly contains all five shades. */}
         <linearGradient id={`${ringId}-water-five`} x1="15" y1="0" x2="92" y2={Math.max(8,100-waterline)} gradientUnits="userSpaceOnUse">
          {item.colors.shades.map((shade:string,index:number)=><stop key={index} offset={`${index*25}%`} stopColor={shade}/>)}
         </linearGradient>
         <radialGradient id={`${ringId}-water-bubble`} cx="30%" cy="24%" r="75%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity=".82"/>
          <stop offset="52%" stopColor={item.colors.shades[1]} stopOpacity=".42"/>
          <stop offset="100%" stopColor={item.colors.shades[4]} stopOpacity=".38"/>
         </radialGradient>
        </defs>
        {/* Flat, animated, theme-colored water: exactly one smooth ring. */}
        <clipPath id={`${ringId}-water-clip`}><circle cx="60" cy="60" r="39.4"/></clipPath>
        <circle className="nb69-water-background" cx="60" cy="60" r="39.4" fill={item.colors.track}/>
        {percent>0&&<g className="nb69-water-window" clipPath={`url(#${ringId}-water-clip)`}>
         <g transform={`translate(0 ${waterline.toFixed(3)})`}>
          <g className="nb70-water-stack">
          <path className="nb70-water-base" fill={`url(#${ringId}-water-five)`} d="M -170 0 H 274 V 160 H -170 Z"/>
          <path className="nb70-water-wave nb70-water-wave--shade1" fill={item.colors.shades[0]} fillOpacity=".48" d="M -170 -3 C -148 -11 -126 -10 -104 -3 S -60 6 -38 -2 S 10 -10 32 -3 S 76 6 98 -2 S 142 -11 164 -3 S 208 6 230 -1 S 252 -9 274 -2 L 274 160 L -170 160 Z"/>
          <path className="nb70-water-wave nb70-water-wave--shade2" fill={item.colors.shades[1]} fillOpacity=".42" d="M -170 6 C -148 -2 -126 -2 -104 6 S -60 14 -38 6 S 10 -2 32 6 S 76 14 98 6 S 142 -2 164 6 S 208 14 230 6 S 252 -2 274 6 L 274 160 L -170 160 Z"/>
          <path className="nb70-water-wave nb70-water-wave--shade3" fill={item.colors.shades[2]} fillOpacity=".40" d="M -170 14 C -146 6 -122 6 -98 14 S -50 22 -26 14 S 22 6 46 14 S 94 22 118 14 S 166 6 190 14 S 238 22 262 14 L 262 160 L -170 160 Z"/>
          <path className="nb70-water-wave nb70-water-wave--shade4 nb69-water-wave nb69-water-wave--back" fill={item.colors.shades[3]} fillOpacity=".47" d="M -170 22 C -146 14 -122 14 -98 22 S -50 30 -26 22 S 22 14 46 22 S 94 30 118 22 S 166 14 190 22 S 238 30 262 22 L 262 160 L -170 160 Z"/>
          <path className="nb70-water-wave nb70-water-wave--shade5 nb69-water-wave nb69-water-wave--front" fill={item.colors.shades[4]} fillOpacity=".53" d="M -170 29 C -144 38 -118 38 -92 29 S -40 20 -14 29 S 38 38 64 29 S 116 20 142 29 S 194 38 220 29 S 246 20 272 29 L 272 160 L -170 160 Z"/>
          {bubbles.map((bubble,index)=><circle key={index} className={`nb70-water-bubble nb70-water-bubble--${index%6}`} cx={bubble.x} cy={Math.max(5,bubbleDepth*bubble.depth)} r={bubble.r} fill={`url(#${ringId}-water-bubble)`} stroke="#ffffff" strokeOpacity=".52" strokeWidth=".6" style={{animationDelay:`-${(index*1.11+{base:0,ready:1.4,deployed:2.7,cyber:4.2}[item.accent as 'base'|'ready'|'deployed'|'cyber']).toFixed(2)}s`,animationDuration:`${(3.7+(index%4)*.72+({base:0,ready:.45,deployed:1.1,cyber:.7}[item.accent as 'base'|'ready'|'deployed'|'cyber'])).toFixed(2)}s`}}/>)}
          </g>
         </g>
        </g>}
        <circle className="nb69-water-outline" cx="60" cy="60" r="39.4" fill="none" stroke={item.colors.track} strokeWidth=".8"/>
        {/* Single non-overlaid progress arc; no duplicate highlights or jagged joins. */}
        <circle cx="60" cy="60" r="48" fill="none" stroke={item.colors.track} strokeWidth="8"/>
        {percent>0&&<circle className="nb68-secondary-arc" cx="60" cy="60" r="41.5" fill="none" stroke={item.colors.light} strokeOpacity=".76" strokeWidth="2.6" strokeDasharray={`${(percent/100*innerCircumference).toFixed(3)} ${innerCircumference.toFixed(3)}`} strokeLinecap={percent>=100?'butt':'round'} transform="rotate(-90 60 60)"/>}
        {percent>0&&<circle className="nb69-progress-arc" cx="60" cy="60" r="48" fill="none" stroke={item.colors.primary} strokeWidth="8" strokeDasharray={`${(percent/100*circumference).toFixed(3)} ${circumference.toFixed(3)}`} strokeLinecap={percent>=100?'butt':'round'} transform="rotate(-90 60 60)"/>}
        <path d="M 30 42 A 39 39 0 0 1 62 22" fill="none" stroke="#ffffff" strokeOpacity=".72" strokeWidth="2.2" strokeLinecap="round"/>
        <path d="M 91 75 A 37 37 0 0 1 66 96" fill="none" stroke="#ffffff" strokeOpacity=".3" strokeWidth="1.4" strokeLinecap="round"/>
       </svg>
      </span>
     </div>
    </button>;
   })}
  </div>

  <div className="nb-overview-layout nb-overview-layout-v062">
   <section className="nb-overview-card nb-overview-attention nb63-attention">
    <div className="nb-overview-card-head">
     <div><h2>Systems requiring attention</h2><p>Issues and unfinished deployment, clearly separated.</p></div>
    </div>
    <div className="nb63-attention-split">
     <div className="nb63-attention-group nb63-attention-issues">
      <div className="nb63-attention-head"><div><span className="nb63-attention-mark nb63-mark-issues"><AlertCircle size={14}/></span><strong>Open issues</strong></div><span className="nb63-attention-count">{openIssues.length}</span></div>
      <div className="nb63-attention-rows">
       {issueRows.length?issueRows.map(({issue,system,severity}:any)=><div className="nb63-attention-item" key={issue.id}>
        <div className="nb63-attention-item-top"><strong title={system?.name||'Unlinked issue'}>{system?.name||'Unlinked issue'}</strong><span className={`nb63-issue-severity nb63-severity-${severity||'unknown'}`}>{issue.severity||'Open'}</span></div>
        <p title={issue.title}>{issue.title||'Issue reported'}</p>
       </div>):<div className="nb63-attention-empty">No open issues.</div>}
      </div>
      <button type="button" className="nb63-attention-footer-link" onClick={()=>onNavigate('issues')}>View Issue Tracker <ChevronRight size={13}/></button>
     </div>
     <div className="nb63-attention-group nb63-attention-progress">
      <div className="nb63-attention-head"><div><span className="nb63-attention-mark nb63-mark-progress"><Settings2 size={14}/></span><strong>Configuration remaining</strong></div><span className="nb63-attention-count">{allSetupRows.length}</span></div>
      <div className="nb63-attention-rows">
       {setupRows.length?setupRows.map(({sys,stage}:any)=><div className={`nb63-attention-item nb73-attention-stage--${stage.className}`} key={sys.id}>
        <div className="nb63-attention-item-top"><strong title={sys.name}>{sys.name}</strong><span className="nb63-setup-percent" title={`${stage.label}: ${stage.complete} / ${stage.total}`}>{stage.percent}%</span></div>
        <div className="nb63-setup-bar" role="progressbar" aria-label={`${sys.name} — ${stage.label}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={stage.percent}><span style={{width:`${stage.percent}%`}}/></div>
        <p><span className="nb73-stage-label">{stage.label}</span><span aria-hidden="true"> · </span>{stage.description}</p>
       </div>):<div className="nb63-attention-empty">All device deployment stages are complete.</div>}
      </div>
      <button type="button" className="nb63-attention-footer-link" onClick={()=>onNavigate('config-report')}>Open Configuration Report <ChevronRight size={13}/></button>
     </div>
    </div>
   </section>

    <section className="nb-overview-card nb-overview-week">
     <div className="nb-overview-card-head">
      <div>
       <h2>This week</h2>
       <p>{`Week ${activeWeek+1} · ${weekRange(project.startDate,activeWeek)}`}</p>
      </div>
      <button type="button" className="nb-overview-link" onClick={()=>onNavigate('roadmap')}>Tracker ↗</button>
     </div>
     <div className="nb-overview-week-stats">
      <article><strong>{weekStats.planned}</strong><span>Planned</span></article>
      <article><strong>{weekStats.active}</strong><span>Active</span></article>
      <article><strong>{weekStats.blocked}</strong><span>Blocked</span></article>
      <article><strong>{weekStats.done}</strong><span>Done</span></article>
     </div>
     <div className="nb-overview-placeholder">
      {currentWeekMilestones.length?currentWeekMilestones.slice(0,3).map((milestone:any)=><div key={milestone.id} className="nb-overview-bullet-row"><strong>{milestone.label}</strong><span>{`Week ${milestone.startWeek+1}`}</span></div>):<p>No milestones scheduled for this and next week.</p>}
     </div>
    </section>

   <section className="nb-overview-card nb-overview-readiness">
    <div className="nb-overview-card-head">
     <div>
      <h2>System readiness</h2>
      <p>Largest inventoried systems · figures from Configuration Report.</p>
     </div>
     <button type="button" className="nb-overview-link" onClick={()=>onNavigate('config-report')}>All systems ↗</button>
    </div>
    <div className="nb-overview-readiness-table">
     <div className="nb-overview-readiness-head"><span>System · Venue</span><span>Qty</span><span>Base</span><span>Ready</span><span>Deployed</span></div>
     {readinessRows.map((sys:any)=>{const c=counts(sys);return <div key={sys.id} className="nb-overview-readiness-row">
      <div><strong>{sys.name}</strong><small>{venueName(sys)}</small></div>
      <div>{c.total}</div>
      <div>{miniProgress(c.base,c.total,'base')}</div>
      <div>{miniProgress(c.ready,c.total,'ready')}</div>
      <div>{miniProgress(c.deployed,c.total,'deployed')}</div>
     </div>;})}
    </div>
   </section>
    <section className="nb-overview-card nb-overview-activity">
     <div className="nb-overview-card-head">
      <div>
       <h2>Recorded activity</h2>
       <p>Saved changes in NBDT.</p>
      </div>
      {activityItems.length>0&&<button type="button" className="nb63-history-link" onClick={()=>setHistoryOpen(true)}>History <ChevronRight size={12}/></button>}
     </div>
     <div className="nb-overview-activity-list">
      {activityItems.length?activityItems.slice(0,3).map((item:any)=><div key={item.id} className="nb-overview-activity-row"><i/><div><strong title={item.title}>{item.title}</strong><small title={item.detail}>{item.detail||item.section||''}</small></div><span>{formatDateTime(item.at)}</span></div>):<p className="nb-overview-empty">New saved changes will appear here.</p>}
     </div>
    </section>

    <section className="nb-overview-card nb-overview-ownership">
     <div className="nb-overview-card-head">
      <div>
       <h2>Ownership coverage</h2>
       <p>Visibility of assigned system owners in this project.</p>
      </div>
      <button type="button" className="nb-overview-link" onClick={()=>onNavigate('assignment')}>Assignment ↗</button>
     </div>
     <div className="nb-overview-coverage">
      <div className="nb-overview-coverage-ring" style={{background:`conic-gradient(#2c77f4 ${Math.round(ownership.assigned/totalSystems*100)}%, #e4edf7 0)`}}><span><strong>{project.systems.length}</strong><small>systems</small></span></div>
      <div className="nb-overview-coverage-legend">
       <div><i className="is-assigned"/>Assigned uniquely <strong>{ownership.assigned}</strong></div>
       <div><i className="is-multiple"/>Multiple owners <strong>{ownership.multiple}</strong></div>
       <div><i className="is-unmatched"/>No exact match <strong>{ownership.unmatched}</strong></div>
      </div>
     </div>
    </section>
  </div>

  {historyOpen&&createPortal(<div className="nb63-activity-backdrop" onMouseDown={(e:any)=>{if(e.target===e.currentTarget)setHistoryOpen(false);}}>
   <section className="nb63-activity-dialog" role="dialog" aria-modal="true" aria-label="Recorded activity history">
    <header><div><h2>Recorded activity</h2><p>Recent saved changes · {activityItems.length} entries</p></div><button type="button" onClick={()=>setHistoryOpen(false)} aria-label="Close activity history"><X size={19}/></button></header>
    <div className="nb63-activity-history">{activityItems.map((item:any)=><article key={item.id}><span className="nb63-history-dot"/><div><strong>{item.title}</strong><p>{item.detail}</p><small>{item.section} · {formatDateTime(item.at)}</small></div></article>)}</div>
   </section>
  </div>,document.body)}
 </section>;}
